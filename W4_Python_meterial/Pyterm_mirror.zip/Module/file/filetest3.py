f = open("linefeedtest.txt", 'wb')
f.write(b'abCD')
f.close
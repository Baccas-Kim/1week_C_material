
mylist = ["test", "python", "good"]

mystr = " ".join(mylist)
print(mystr)
a = 33; b=77
temp = "a+b"
print(eval(temp))
a = 3
b = 2
print(eval(temp))

print( [2, 3] == [ 2, 3, 5])

func = lambda x : print("on") if x==1 else print("off")

func(1)
func(0)
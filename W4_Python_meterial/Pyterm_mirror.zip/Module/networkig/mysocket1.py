from socket import *
#import socket

mysock = socket(AF_INET, SOCK_STREAM)
print(mysock)

#myip_info = gethostbyname("google.com")
#print(myip_info)
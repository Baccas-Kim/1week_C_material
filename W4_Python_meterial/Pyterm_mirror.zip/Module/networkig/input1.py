data = int(input("input :"))
print(data)
print(type(data))
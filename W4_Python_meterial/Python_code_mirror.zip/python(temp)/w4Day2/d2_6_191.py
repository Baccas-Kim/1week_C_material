#d3_6_191p

myaddr = {'kdh:123-456', 'aaa:111-111', 'bbb:222-222', 'ccc:333-333'}

if myaddr in kdh:
	print("kdh is in dict")
print("not in dict")


a = 5
b = 6.6
c = "python"

print("a: ",a)
print("hello world!")
print(type(a))
print(type(b))
print(type(c))
print(id(a))
print(id(b))
print(id(c))
print(a)


#x = 15
#x<<=3
#print(x)

a = 100
b = -77

 = not a + 1
b = not b
a+=1
b+=1
print(a)
print(b)

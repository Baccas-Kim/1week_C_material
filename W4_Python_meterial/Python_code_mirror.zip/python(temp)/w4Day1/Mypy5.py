#for x in range(1,10):
#	res = x>5 and 10 or 20
#	print(x,res)

#a=1000
#b=1000
#print(id(a))
#print(id(b))

def func1();

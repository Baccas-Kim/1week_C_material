#ID_1 = "apple"
#ID_2 = "Bnana"
#print(ID_1 < ID_2)

fdata_1 = 5.12341234
fdata_2 = 9.56785678

print("{0:0}".format(fdata_1))
print("{0:0.4f}".format(fdata_1))
print("{0:10.4f} or {1:10.3f}".format(fdata_1,fdata_2)) 
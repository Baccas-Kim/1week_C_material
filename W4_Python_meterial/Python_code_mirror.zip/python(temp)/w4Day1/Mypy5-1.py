def  func1():
	c=257
	print(id(c))
d=257
print(id(d))
func1()
mystr = "Hello python Proggramming laguage"

print('ro' in mystr)

count = 0
for s in mystr:
	if s == 'lo':
		count+=1
print("o char count: %d" %count)
str1 = "Good"
str2 = "python programming"
str3 = str1 + " " + str2
print(str3)

stm = "Python_string"
print(stm*3)

sti = "string_idx"
print(sti[0],sti[1],sti[len(sti)-1])
print(sti[::-1])
print(sti[::1])


s = 'python'
print(s[0:6])

print(s[0:])

print(s[:])

print(s[0:-1])

print(s[0:-2])

print(s[0:-3])


print(100/9)
print(100//9)
print(100%9)
print(divmod(100,9))

a=1
b=2.0
c=a+b
print(c)
print(2**3)

x=77.0
x//=7
x+=1
print(x)
print(x)
x+=1
print(x)
x+=1
print(x)
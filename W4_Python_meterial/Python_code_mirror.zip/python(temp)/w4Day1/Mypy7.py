str1 = 'python'
print(str1)

str2 = "I'm python"
print(str2)

str3 = '"Good python"'
print(str3)

str4 = """Python
is
Good
Easy"""
print(str4)
print("\a\a\a")
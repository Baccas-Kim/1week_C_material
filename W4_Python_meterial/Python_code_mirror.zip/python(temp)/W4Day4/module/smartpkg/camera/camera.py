#camera
def photo():
	print("Taka a photo")

if __name__ == '__main__':
	photo()
	print("camera.py's module name is", __name__)
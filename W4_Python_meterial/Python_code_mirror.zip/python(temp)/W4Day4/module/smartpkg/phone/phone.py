#phone_base.py
def makeacall():
	print("makeacall")

if __name__ == '__main__':

	makeacall()
	print("phone.py's moulde name is : __name__")

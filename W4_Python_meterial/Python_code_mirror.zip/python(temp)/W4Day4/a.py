
import b
var = 100
def a():
	print(var)
	
b.b()
#print("Hw")
a()
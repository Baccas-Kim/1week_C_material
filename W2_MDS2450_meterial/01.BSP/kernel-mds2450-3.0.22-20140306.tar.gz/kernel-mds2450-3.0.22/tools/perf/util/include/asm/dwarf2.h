
#ifndef PERF_DWARF2_H
#define PERF_DWARF2_H

/* dwarf2.h ... dummy header file for including arch/x86/lib/memcpy_64.S */

#define CFI_STARTPROC
#define CFI_ENDPROC

#endif	/* PERF_DWARF2_H */


#ifndef _PERF_DWARF_REGS_H_
#define _PERF_DWARF_REGS_H_

#ifdef DWARF_SUPPORT
const char *get_arch_regstr(unsigned int n);
#endif

#endif

#ifndef _PERF_UI_H_
#define _PERF_UI_H_ 1

#include <pthread.h>

extern pthread_mutex_t ui__lock;

#endif /* _PERF_UI_H_ */

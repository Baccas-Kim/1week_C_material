/*** CHTBL.C : Chained Hash Table Source ***/
/*** Programmed by gurndari ***/

#include <stdio.h>
#include <stdlib.h>

#include "list.h"
#include "chtbl.h"

#define MAX 21
#define HTs 11  /* Hash Table size */

int  h_code(char *str);
int  h_key(const void *key);
int  match_cmp(const void *key1, const void *key2);
void StartHash(CHTbl *htbl);
int  CHTMenu(void);
int  HashTable_Print(CHTbl *htbl);
ListElmt *HashTable_Find(CHTbl *htbl);

int main(void) {
	CHTbl *htbl;
	if((htbl=(CHTbl *)malloc(sizeof(CHTbl)))==NULL)
		return 1;
	if(chtbl_init(htbl, HTs, h_key, match_cmp, free)!=0)
		return 1;
	StartHash(htbl);
	return 0;
}
void StartHash(CHTbl *htbl) {
	int select;
	static void *str;
	static void *str1;
	ListElmt *element;
	while((select=CHTMenu())!=0) {
		switch(select) {
			case 1 :
				printf("Input string : ");
				scanf("%s", &str);
				if(chtbl_insert(htbl, &str)==1)
					printf("Error : Do not insert\n");
				break;
			case 2 :
				printf("Input delete string : ");
				scanf("%s", &str1);
				str=&str1;
				if((chtbl_remove(htbl, (void **)&str))!=0)
					printf("Data not exist or not found\n");
				else {
					printf("Yes! Destroy !\n");
					htbl->destroy(str);
				}
				break;
			case 3 :
				if((element=HashTable_Find(htbl))!=NULL)
					printf("Found '%s' !\n", list_data(element));
				else
					printf("Not Found !\n");
				break;
			case 4 :
				if(HashTable_Print(htbl)!=0)
					printf("Data not exist\n");
				break;
			case 5 :
				chtbl_destroy(htbl);
				break;
		}
	}
	clrscr();
	printf("Dream of 'Laputa' !\n");
	exit(0);
}
/*** Generation bucket code ***/
int h_key(const void *key) {
	int h;
	char str[MAX];
	strcpy(str, (char *)key);
	h=h_code(str); /* Make Bucket Code */
	return h;
}
/*** Charaters Divide and Addtion ***/
int h_code(char *str) {
	int h=0;
	while(*str)
		h+=*str++;
	return h%HTs;
}
/* string compare */
int match_cmp(const void *key1, const void *key2) {
	return (strcmp((const char *)key1, (const char *)key2) ? 0 : 1);
}
int CHTMenu(void) {
	int select;
	do {
		printf("\n\nChained Hash Table Menu\n");
		printf("1. Insert the Hash Table\n");
		printf("2. Delete next element in the Hash Table\n");
		printf("3. Find a element in the Hash Table\n");
		printf("4. Print all element of the Hash Table\n");
		printf("5. Destroy all element of the Hash Table\n");
		printf("0. Quit\n");
        printf("*** String limit is 20 character ***\n");
		printf("Select Operation : ");
		scanf("%d", &select);
	} while(select<0 || select>5);
	return select;
}
int HashTable_Print(CHTbl *htbl) {
	int i;
	ListElmt *element;
	printf("Chained hash table size is %d\n", chtbl_size(htbl));
	if(htbl->table==NULL || chtbl_size(htbl)==0)
		return 1;
	printf("  Table : List (size)  (contents : Head->Tail)");
	for(i=0; i<HTs; i++) {
		printf("\nBucket[%02d] : [%02d] : ", i, list_size(&htbl->table[i]));
		for(element=list_head(&htbl->table[i]); element!=NULL; element=list_next(element))
			printf("%s. ", list_data(element));
	}
	return 0;
}
ListElmt *HashTable_Find(CHTbl *htbl) {
	int bucket;
	static void *str;
	ListElmt *element;
	if(htbl->table==NULL || chtbl_size(htbl)==0)
		return NULL;
	printf("Input found string : ");
	scanf("%s", &str);
	bucket=htbl->h(&str) % htbl->buckets;
	for(element=list_head(&htbl->table[bucket]); element!=NULL; element=list_next(element))
		if(htbl->match(&str, list_data(element)))
			return element;
	return NULL;
}

/***********************************************************/
/**************** Chained Hash Table Source ****************/
/***********************************************************/
int chtbl_init(CHTbl *htbl, int buckets, int (*h)(const void *key),
			   int (*match)(const void *key1, const void *key2),
			   void (*destroy)(void *data)) {
	int i;
	if((htbl->table=(List *)malloc(sizeof(List)*buckets))==NULL)
		return -1;
	htbl->buckets=buckets;
	for(i=0; i<htbl->buckets; i++)
		list_init(&htbl->table[i], destroy);
	htbl->h=h;
	htbl->match=match;
	htbl->destroy=destroy;
	htbl->size=0;
	return 0;
}
int chtbl_insert(CHTbl *htbl, const void *data) {
	void *temp;
	int bucket, retval;
	temp=(void *)data;
	if(chtbl_lookup(htbl, &temp)==0)
		return 1;
	bucket=htbl->h(data) % htbl->buckets;
	if((retval=list_ins_next(&htbl->table[bucket], NULL, data))==0)
		htbl->size++;
	return retval;
}
int chtbl_remove(CHTbl *htbl, void **data) {
	ListElmt *element, *prev;
	int bucket;
	bucket=htbl->h(*data) % htbl->buckets;
	prev=NULL;
	for(element=list_head(&htbl->table[bucket]); element!=NULL; element=list_next(element)) {
		if(htbl->match(*data, list_data(element))) {
			if(list_rem_next(&htbl->table[bucket], prev ,data)==0) {
				htbl->size--;
				return 0;
			}
			else
				return -1;
		}
		prev=element;
	}
	return -1;
}
int chtbl_lookup(const CHTbl *htbl, void **data) {
	ListElmt *element;
	int bucket;
	bucket=htbl->h(*data)%htbl->buckets;
	for(element=list_head(&htbl->table[bucket]); element!=NULL; element=list_next(element)) {
		if(htbl->match(*data, list_data(element))) {
			*data=list_data(element);
			return 0;
		}
	}
	return -1;
}
void chtbl_destroy(CHTbl *htbl) {
	int i;
	for(i=0; i<htbl->buckets; i++)
		list_destroy(&htbl->table[i]);
	free(htbl->table);
	memset(htbl, 0, sizeof(CHTbl));
	return;
}

/***********************************************************/
/*************** Simple Linked List Source *****************/
/***********************************************************/
int list_init(List *list, void (*destroy)(void *data)) {
    list->size=0;
    list->destroy=destroy;
    list->head=NULL;
    list->tail=NULL;
    return 1;
}
int list_ins_next(List *list, ListElmt *element, const void *data) {
    ListElmt *new_element;
    if((new_element=(ListElmt *)malloc(sizeof(ListElmt)))==NULL)
	return -1;
    strcpy(new_element->data, (char *)data);
    if(element==NULL) {
	if(list_size(list)==0)
	    list->tail=new_element;
		new_element->next=list->head;
		list->head=new_element;
    }
    else {
		if(element->next==NULL)
			list->tail=new_element;
		new_element->next=element->next;
		element->next=new_element;
    }
    list->size++;
    return 0;
}
void list_destroy(List *list) {
    void *data;
    while(list_size(list)>0) {
		if(list_rem_next(list, NULL, (void **)&data)==0 &&
				list->destroy!=NULL) {
			list->destroy(data);
		}
    }
    memset(list, 0, sizeof(List));
    return;
}
int list_rem_next(List *list, ListElmt *element, void **data) {
	ListElmt *old_element;
	if(list_size(list)==0)
		return -1;
	if(element==NULL) {
		*data=list->head->data;
		old_element=list->head;
		list->head=list->head->next;
		if(list_size(list)==0)
			list->tail=NULL;
	}
	else {
		if(element->next==NULL)
			return -1;
		*data=element->next->data;
		old_element=element->next;
		element->next=element->next->next;
		if(element->next==NULL)
			list->tail=element;
	}
	free(old_element);
	list->size--;
	return 0;
}

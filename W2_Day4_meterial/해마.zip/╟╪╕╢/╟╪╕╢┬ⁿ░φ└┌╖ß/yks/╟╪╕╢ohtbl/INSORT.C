#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mem.h>

#define MAX 10

typedef int (*FCMP)(const void *, const void *);

void InsertSort(char item[], int count);
void Insert_Sort(void *base, size_t nelem, size_t width, FCMP fcmp);
int  charcmp(const void *key1, const void *key2);

void main(void) {
	int i;
	char data[MAX];
	randomize();
	for(i=0; i<MAX; i++)
		data[i]=random(MAX)+97;
	printf("\nInsert_Sort_Library\n");
	for(i=0; i<MAX; i++)
		printf(" %c ", data[i]);
	printf("\n");
	/*InsertSort(data, MAX);*/
	Insert_Sort((void *)data, MAX, sizeof(char), charcmp);
	for(i=0; i<MAX; i++)
		printf(" %c ", data[i]);
}
void InsertSort(char item[], int count) {
	int i, j, temp;
	for(i=1; i<count; i++) {
		temp=item[i];
		j=i-1;
		while(j>=0 && item[j]>temp) {
			item[j+1]=item[j];
			j--;
		}
		item[j+1]=temp;
	}
	for(i=0; i<count; i++)
		printf(" %c ", item[i]);
	printf("\n");
}
void Insert_Sort(void *base, size_t nelem, size_t width, FCMP fcmp) {
	int i, j;
	void *temp;
	temp=malloc(width);
	for(i=1; i<nelem; i++) {
		memcpy(temp, (char *)base+i*width, width);
		j=i;
		while(fcmp((char *)base+(j-1)*width, temp)>0 && j>0) {
			memcpy((char *)base+j*width, (char *)base+(j-1)*width, width);
			j--;
		}
		memcpy((char *)base+j*width, temp, width);
	}
	free(temp);
}
int charcmp(const void *key1, const void *key2) {
	int i;
	i=strcmp((char *)key1, (char *)key2);
	if(i==0) return 0;
	if(i==1) return 1;
	if(i==-1) return -1;
}
strcmp((char *)key1, (char *)key2) ? 0 : 1
/*Main of the Double linked list*/
/*Programmed by Gurndari*/

#include <stdio.h>
#include <alloc.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <mem.h>

#include "dlist.h"
#define MAX 20
void StartDoubleList(DList *list);
int  DLMenu(void);
int  prev_next(void);
void dlist_insert(DList *list, DListElmt *element);
void dlist_ins_prev_or_next(DList *list);
void dlist_print(DList *list);
DListElmt *dlist_find(DListElmt *element);
void dlist_select_sort(DList *list);

void main(void) {
	DList *list;
	if((list=(DList *)malloc(sizeof(DList)))==NULL) {
		printf("Failure : Memory allocation !\n");
		return;
	}
	dlist_init(list, free);
	StartDoubleList(list);
}

void StartDoubleList(DList *list) {
	int select;
	void *str;
	void *data;
	DListElmt *element;
	while((select=DLMenu())!=0) {
		switch(select) {
			case 1 :
				dlist_insert(list, dlist_head(list));
				break;
			case 2 :
				dlist_ins_prev_or_next(list);
				break;
			case 3 :
				if((element=dlist_find(dlist_head(list)))!=NULL)
					printf("Found %s !\n", dlist_data(element));
				else
					printf("Data not Exist or Not Found !\n");
				break;
			case 4 :
				if((element=dlist_find(dlist_head(list)))==NULL)
					printf("Not Found !\n");
				else {
					dlist_remove(list, element, (void **)&data);
					list->destroy(data);
				}
				break;
			case 5 :
				dlist_destroy(list);
				break;
			case 6 :
				dlist_print(list);
				break;
			case 7 :
				dlist_select_sort(list);
				break;
		}
	}
	clrscr();
	printf("Good Luck !\n");
	exit(0);
}

/*Menu of the double linked list*/
int DLMenu(void) {
	int i;
	do {
		printf("\nDouble Linked List MEMU\n");
		printf("1. dlist_ins(prev)\n");
		printf("2. dlist_ins_prev_or_next\n");
		printf("3. dlist_find\n");
		printf("4. dlist_remove\n");
		printf("5. dlist_destroy\n");
		printf("6. diist_print\n");
		printf("7. dlist_select_sort\n");
		printf("0. Quit\n");
		printf("Select Operation : ");
		scanf("%d", &i);
	} while(i<0||i>7);
	return i;
}

void dlist_insert(DList *list, DListElmt *element) {
	static void *str;
	printf("Input string : ");
	scanf("%s", &str);
	if(dlist_ins_prev(list, element, &str)==-1) {
		printf("Error : to operation insert\n");
		return;
	}
}

void dlist_ins_prev_or_next(DList *list) {
	int i;
	static void *str;
	DListElmt *element;
	if((element=dlist_find(dlist_head(list)))==0) {
		printf("Error : Data not exist\n");
		return;
	}
	i=prev_next();
	printf("Input string : ");
	scanf("%s", &str);
	if(i==1)
		dlist_ins_prev(list, element, &str);
	else
		dlist_ins_next(list, element, &str);
}

int prev_next(void) {
	int i;
	clrscr();
	printf("1. Insert previous\n");
	printf("2. Insert next\n");
	printf("Operation : ");
	scanf("%d", &i);
	return i;
}

void dlist_print(DList *list) {
	int i=0;
	DListElmt *element;
	element=dlist_head(list);
	printf("DList size is %d\n", dlist_size(list));
	printf("DList contents : Head ===> Tail\n");
	while(element!=NULL) {
		printf("%19s", dlist_data(element));
		element=dlist_next(element);
		i++;
		if(i>=4) {
			printf("\n");
			i=0;
		}
	}
}

DListElmt *dlist_find(DListElmt *element) {
	static void *str;
	if(element==NULL)
		return NULL;
	printf("Search String ? ");
	scanf("%s", &str);
	while(strcmp(dlist_data(element), (char *)&str) && element!=NULL)
		element=dlist_next(element);
	return element;
}
void dlist_select_sort(DList *list) {
	DListElmt *old_element, *element, *change;
	DListElmt *temp;
	if((temp=(DListElmt *)malloc(sizeof(DListElmt)))==NULL)
		return;

	element=dlist_head(list);
	old_element=(dlist_next(element));
	for(element=dlist_head(list); element->next!=NULL; element=dlist_next(element)) {
		change=element;
		strcpy(dlist_data(temp), dlist_data(element));
		for(old_element=dlist_next(element); old_element!=NULL; old_element=dlist_next(old_element))
			if(strcmp(dlist_data(temp), dlist_data(old_element))>0) {
				strcpy(dlist_data(temp), dlist_data(old_element));
				change=old_element;
			}
		strcpy(dlist_data(change), dlist_data(element));
		strcpy(dlist_data(element), dlist_data(temp));
	}
	free(temp);
}



/*initialize the double linked list*/
void dlist_init(DList *list, void (*destroy)(void *data)) {
	list->size=0;
	list->destroy=destroy;
	list->head=NULL;
	list->tail=NULL;
	return;
}

/*insert previous the double linked list*/
int dlist_ins_prev(DList *list, DListElmt *element, const void *data) {
	DListElmt *new_element;
	if(element==NULL && dlist_size(list)!=0)
		return -1;
	if((new_element=(DListElmt *)malloc(sizeof(DListElmt)))==NULL)
		return -1;
	strcpy(new_element->info, (char *)data);
	if(dlist_size(list)==0) {
		list->head=new_element;
		new_element->prev=NULL;
		new_element->next=NULL;
		list->tail=new_element;
	}
	else {
		new_element->next=element;
		new_element->prev=element->prev;
		if(element->prev==NULL)
			list->head=new_element;
		else
			element->prev->next=new_element;
		element->prev=new_element;
	}
	list->size++;
	return 0;
}

int dlist_ins_next(DList *list, DListElmt *element, const void *data) {
	DListElmt *new_element;
	/*do not allow a NULL element unless the list is empty.*/
	if(element==NULL&&dlist_size(list)!=0)
		return -1;
	/*allocate storage for the element*/
	if((new_element=(DListElmt *)malloc(sizeof(DListElmt)))==NULL)
		return -1;
	/*insert the new element into the list
	new_element->data=(void *)data;*/
	strcpy(new_element->info, (char *)data);
	if(dlist_size(list)==0) {
		list->head=new_element;
		list->head->prev=NULL;
		list->head->next=NULL;
		list->tail=new_element;
	}
	else {
		new_element->next=element->next;
		new_element->prev=element;
		if(element->next==NULL)
			list->tail=new_element;
		else
			element->next->prev=new_element;
		element->next=new_element;
	}
	/*adjust the size of the list to account for the inserted element*/
	list->size++;
	return 0;
}

/*destroy the double linked list(all element)*/
void dlist_destroy(DList *list) {
	void *data;
	/*remove each element.*/
	while(dlist_size(list)>0)
		if(dlist_remove(list, dlist_tail(list), (void **)&data)==0 && list->destroy!=NULL)
			list->destroy(data);
	memset(list, 0, sizeof(DList));
	return;
}

/*remove the element in the double linked list(one element)*/
int dlist_remove(DList *list, DListElmt *element, void **data) {
	/*do not allow a NULL element or removal from an empty list*/
	if(element==NULL||dlist_size(list)==0)
		return -1;
	/*remove the element from the list*/
	*data=element->info;
	if(element==list->head) {
		list->head=element->next;
		if(list->head==NULL)
			list->tail=NULL;
		else
			element->next->prev=NULL;
	}
	else {
		element->prev->next=element->next;
		if(element->next==NULL)
			list->tail=element->prev;
		else
			element->next->prev=element->prev;
	}
	/*free the storage allocated by the abstract data type*/
	free(element);
	/*adjust the size of the list to account for the removed element*/
	list->size--;
	return 0;
}
/******** Binary  Tree ********/
/*** Programmed by Gurndari ***/

#include <stdlib.h>
#include <string.h>

#include "bitree.h"
#define MAX 99

int BiTreeArray[MAX];
int index;

int  BiTree_Menu(void);
void StartBinaryTree(BiTree *tree);
int  BiTree_Insert(BiTree *tree, void *key);
BiTreeNode *BiTree_Find(BiTree *tree);
void RemoveLeftOrRight(BiTree *tree);
int  intcmp(const void *key1, const void *key2);
int  print_tree(BiTree *tree);
void print_preorder(BiTreeNode *node);
void print_inorder(BiTreeNode *node);
void print_postorder(BiTreeNode *node);
void BiTreeSort(BiTreeNode *node);
BiTreeNode *BiTreeBalance(int size);

int main(void) {
	BiTree *tree;
	if((tree=(BiTree *)malloc(sizeof(BiTree)))==NULL)
		return -1;
	bitree_init(tree, free);
	StartBinaryTree(tree);
	free(tree);
	return 0;
}
void StartBinaryTree(BiTree *tree) {
	int  select, size;
	void *key, *temp;
	BiTreeNode *node;
	while((select=BiTree_Menu())!=0) {
		switch(select) {
			case 1 :
				if((key=(void *)malloc(sizeof(int)))==NULL)
					return;
				printf("Input value : ");
				scanf("%d", key);
				if(BiTree_Insert(tree, key)!=0) {
					printf("Already exist or Do not insert\n");
					free(key);
				}
				break;
			case 2 :
				if((node=BiTree_Find(tree))!=NULL)
					printf("Find value : %d\n", *(int *)bitree_data(node));
				else
					printf("Do not find.\n");
				break;
			case 3 :
				RemoveLeftOrRight(tree);
				break;
			case 4 :
				break;
			case 5 :
				index=0;
				BiTreeSort(bitree_root(tree));
				size=bitree_size(tree);
				bitree_destroy(tree);
				index=0;
				tree->root=BiTreeBalance(size);
				tree->size=size;
				break;
			case 6 :
				if(print_tree(tree)!=0)
					printf("Data not exist in the Tree.\n");
				break;
			case 7 :
				bitree_destroy(tree);
				break;
		}
	}
	clrscr();
	printf("Dream of 'Laputa'\n");
	exit(0);
}
int BiTree_Menu(void) {
	int select;
	do {
		printf("\n\nBinary Tree Menu.\n");
		printf("1. Insert the Tree.\n");
		printf("2. Find the Tree.\n");
		printf("3. Delete left or right of the node in the Tree.\n");
		printf("4. .\n");
		printf("5. Make Balanced Binary Tree.\n");
		printf("6. Print Tree(Preorder, Inorder, Postorder.\n");
		printf("7. Destroy the Binary Tree.\n");
		printf("0. Quit.\n");
		printf("Input value is between 0 and 99.\n");
		printf("Select Operation : ");
		scanf("%d", &select);
	} while(select<0 || select>7);
	return select;
}
int BiTree_Insert(BiTree *tree, void *key) {
	BiTreeNode *parent, *child;
	child=bitree_root(tree);
	parent=child;
	while(!bitree_is_eob(child)) {
		parent=child;
		if(intcmp(key, bitree_data(child))==0)
			return -1;
		if(intcmp(key, bitree_data(child))<0)
			child=bitree_left(child);
		else
			child=bitree_right(child);
	}
	if((intcmp(key, bitree_data(parent))<0) || parent==child)
		bitree_ins_left(tree, parent, key);
	else
		bitree_ins_right(tree, parent, key);
	return 0;
}
BiTreeNode *BiTree_Find(BiTree *tree) {
	void *temp, *key;
	BiTreeNode *node;
    printf("Input Find key : ");
	scanf("%d", &key);
	node=bitree_root(tree);
	while(intcmp(&key, bitree_data(node))!=0 && node!=NULL) {
		if(intcmp(&key, bitree_data(node))<0)
			node=bitree_left(node);
		else
			node=bitree_right(node);
	}
	if(node==NULL)
		return NULL;
	else 
		return node;
}
void RemoveLeftOrRight(BiTree *tree) {
	BiTreeNode *node;
	if((node=BiTree_Find(tree))!=NULL) {
		switch(LeftOrRightMenu()) {
			case 1 : bitree_rem_left(tree, node); break;
			case 2 : bitree_rem_right(tree, node); break;
		}
	}
	else
		printf("Do not find.\n");
	return;
}
int LeftOrRightMenu(void) {
	int select;
	do {
    	printf("1. Remove left.\n");
		printf("2. Remove right.\n");
		printf("Selection : ");
		scanf("%d", &select);
	} while(select<1 || select>2);
	return select;
}

int intcmp(const void *key1, const void *key2) {
	return (*(int *)key1 - *(int *)key2);
}
int print_tree(BiTree *tree) {
	if(bitree_root(tree)==NULL)
		return -1;
	printf("Binary Tree size is %d.\n", bitree_size(tree));
	printf("Preorder  : ");
	print_preorder(bitree_root(tree));
	printf("\nInorder   : ");
	print_inorder(bitree_root(tree));
	printf("\nPostorder : ");
	print_postorder(bitree_root(tree));
	printf("\n");
	return 0;
}
void print_preorder(BiTreeNode *node) {
	if(!bitree_is_eob(node)) {
		printf("[%2d] ", *(int *)bitree_data(node));
		if(!bitree_is_eob(bitree_left(node)))
			print_preorder(bitree_left(node));
		if(!bitree_is_eob(bitree_right(node)))
			print_preorder(bitree_right(node));
	}
	return;
}
void print_inorder(BiTreeNode *node) {
	if(!bitree_is_eob(node)) {
		if(!bitree_is_eob(bitree_left(node)))
			print_inorder(bitree_left(node));
		printf("[%2d] ", *(int *)bitree_data(node));
		if(!bitree_is_eob(bitree_right(node)))
			print_inorder(bitree_right(node));
	}
	return;
}
void print_postorder(BiTreeNode *node) {
	if(!bitree_is_eob(node)) {
		if(!bitree_is_eob(bitree_left(node)))
			print_postorder(bitree_left(node));
		if(!bitree_is_eob(bitree_right(node)))
			print_postorder(bitree_right(node));
		printf("[%2d] ", *(int *)bitree_data(node));
	}
	return;
}
void BiTreeSort(BiTreeNode *node) {
    if(!bitree_is_eob(node)) {
		if(!bitree_is_eob(bitree_left(node)))
			BiTreeSort(bitree_left(node));
		BiTreeArray[index++]=*(int *)bitree_data(node);
		if(!bitree_is_eob(bitree_right(node)))
			BiTreeSort(bitree_right(node));
	}
	return;
}
BiTreeNode *BiTreeBalance(int size) {
	int *temp;
	int leftsize, rightsize;
	BiTreeNode *node;
	if(size>0) {
		leftsize=(size-1)/2;
		rightsize=size-leftsize-1;
		node=(BiTreeNode *)malloc(sizeof(BiTreeNode));
		node->left=BiTreeBalance(leftsize);
		temp=(int *)malloc(sizeof(int));
		*temp=BiTreeArray[index++];
		node->data=(void *)temp;
		node->right=BiTreeBalance(rightsize);
		return node;
	}
	else
		return NULL;
}

/********** Binary Tree Source **********/
void bitree_init(BiTree *tree, void (*destroy)(void *data)) {
	tree->size=0;
	tree->destroy=destroy;
	tree->root=NULL;
	return;
}
int bitree_ins_left(BiTree *tree, BiTreeNode *node, const void *data) {
	BiTreeNode *new_node, **position;
	if(node==NULL) {
		if(bitree_size(tree)>0)
			return -1;
		position=&tree->root;
	}
	else {
		if(bitree_left(node)!=NULL)
			return -1;
		position=&node->left;
	}
	if((new_node=(BiTreeNode *)malloc(sizeof(BiTreeNode)))==NULL)
		return -1;
	new_node->data=(void *)data;
	new_node->left=NULL;
	new_node->right=NULL;
	*position=new_node;
	tree->size++;
	return 0;
}
int bitree_ins_right(BiTree *tree, BiTreeNode *node, const void *data) {
	BiTreeNode *new_node, **position;
	if(node==NULL) {
		if(bitree_size(tree)>0)
			return -1;
		position=&tree->root;
	}
	else {
		if(bitree_right(node)!=NULL)
			return -1;
		position=&node->right;
	}
    if((new_node=(BiTreeNode *)malloc(sizeof(BiTreeNode)))==NULL)
		return -1;
	new_node->data=(void *)data;
	new_node->left=NULL;
	new_node->right=NULL;
	*position=new_node;
	tree->size++;
	return 0;
}
void bitree_destroy(BiTree *tree) {
	bitree_rem_left(tree, NULL);
	memset(tree, 0, sizeof(BiTree));
	return;
}
void bitree_rem_left(BiTree *tree, BiTreeNode *node) {
	BiTreeNode **position;
	if(bitree_size(tree)==0)
		return;
	if(node==NULL)
		position=&tree->root;
	else
		position=&node->left;
	if(*position!=NULL) {
		bitree_rem_left(tree, *position);
		bitree_rem_right(tree, *position);
		if(tree->destroy!=NULL)
			tree->destroy((*position)->data);
		free(*position);
		*position=NULL;
		tree->size--;
	}
	return;
}
void bitree_rem_right(BiTree *tree, BiTreeNode *node) {
	BiTreeNode **position;
	if(bitree_size(tree)==0)
		return;
	if(node==NULL)
		position=&tree->root;
	else
		position=&node->right;
	if(*position!=NULL) {
		bitree_rem_left(tree, *position);
		bitree_rem_right(tree, *position);
		if(tree->destroy!=NULL)
			tree->destroy((*position)->data);
		free(*position);
		*position=NULL;
		tree->size--;
	}
	return;
}
int bitree_merge(BiTree *merge, BiTree *left, BiTree *right, const void *data) {
	bitree_init(merge, left->destroy);
	if(bitree_ins_left(merge, NULL, data)!=0) {
		bitree_destroy(merge);
		return -1;
	}
	bitree_root(merge)->left=bitree_root(left);
	bitree_root(merge)->right=bitree_root(right);
	merge->size=merge->size+bitree_size(left)+bitree_size(right);
	left->root=NULL;
	left->size=0;
	right->root=NULL;
	right->size=0;
	return 0;
}
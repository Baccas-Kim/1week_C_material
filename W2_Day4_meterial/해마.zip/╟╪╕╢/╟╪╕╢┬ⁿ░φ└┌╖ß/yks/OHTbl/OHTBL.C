/* Open Addressd Hash Table */
/*  Programmed by gurndari  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ohtbl.h"

#define MAX 21
#define HTs 11 /* Open Address Hash Table Size */

void StartOHTbl(OHTbl *htbl);
int  OHTbl_Menu(void);
int  OHTbl_print(OHTbl *htbl);
int  Hash_Insert(OHTbl *htbl);
int  Hash_Find(OHTbl *htbl, void *data);
int  hash1(const void *key);
int  hash2(const void *key);
int  h_code1(char *str);
int  h_code2(char *str);
int  match_str(const void *key1, const void *key2);

int main(void) {
	OHTbl *htbl;
	if((htbl=(OHTbl *)malloc(sizeof(OHTbl)))==NULL)
		return 1;
	if(ohtbl_init(htbl, HTs, hash1, hash2, match_str, free)!=0)
		return 1;
	StartOHTbl(htbl);
	return 0;
}
void StartOHTbl(OHTbl *htbl) {
	int select;
	void *str;
	void *temp;
	while((select=OHTbl_Menu())!=0) {
		switch(select) {
			case 1 :
				if(Hash_Insert(htbl)!=0)
					printf("Table full of Data exist\n");
				break;
			case 2 :
				printf("Input delete characer : ");
				scanf("%s", &temp);
				str=&temp;
				if(ohtbl_remove(htbl, (void **)&str)!=0)
					printf("Data not exist\n");
				else
					printf("Yes! Destroy\n");
				htbl->destroy(str);
				break;
			case 3 :
				printf("Input find character : ");
				scanf("%s", &temp);
				str=&temp;
				if(Hash_Find(htbl, str)==0)
					printf("Found !\n");
				else
					printf("Table empty or Not found !\n");
				htbl->destroy(str);
				break;
			case 4 :
				if(OHTbl_print(htbl)!=0)
					printf("Data not exist.\n");
				break;
			case 5 :
				ohtbl_destroy(htbl);
				break;
		}
	}
	clrscr();
	printf("Dream of 'Laputa'\n");
	exit(0);
}
int OHTbl_Menu(void) {
	int select;
	do {
		printf("\n\nOpen Address Hash Table Menu.\n");
		printf("1. Insert the OHTbl.\n");
		printf("2. Delete of current position that found in the OHTbl.\n");
		printf("3. Find in the OHTbl.\n");
		printf("4. Print all that the OHTbl.\n");
		printf("5. Destroy all of the OHTbl.\n");
		printf("0. Quit.\n");
		printf("*** String limit is 20 character ***\n");
		printf("Select Operation : ");
		scanf("%d", &select);
	} while(select<0 || select>5);
	return select;
}
int Hash_Insert(OHTbl *htbl) {
	int i;
	void *str;
	if((str=(void *)malloc(sizeof(char[MAX])))==NULL)
		return -1;
	printf("Input one charater : ");
	scanf("%s", str);
	if(ohtbl_insert(htbl, str)!=0)
		return -1;
	return 0;
}
int Hash_Find(OHTbl *htbl, void *data) {
	int position, i;
    if(htbl->table==NULL || ohtbl_size(htbl)==0)
		return -1;
	printf("Hash status for finding '%s'\n", (char *)data);
	for(i=0; i<htbl->positions; i++) {
		position=(htbl->h1(data)+(i*htbl->h2(data))) % htbl->positions;
		printf("[%02d] ", position);
		if(htbl->table[position]!=NULL || htbl->table[position]!=htbl->vacated)
			if((htbl->match(htbl->table[position], data))!=0)
				return 0;
	}
	printf("\n");
	return -1;
}
int OHTbl_print(OHTbl *htbl) {
	int i;
	printf("Open Address Hash Table size is %d.\n", ohtbl_size(htbl));
	if(htbl->table==NULL || ohtbl_size(htbl)==0)
		return -1;
	for(i=0; i<HTs; i++) {
		if(htbl->table[i]!=NULL && htbl->table[i]!=htbl->vacated)
			printf("OHTbl[%02d] : %s\n", i, (char *)htbl->table[i]);
	}
	return 0;
}
/*** Primary Hash Function ***/
int hash1(const void *key) {
	char str[MAX];
	strcpy(str, (char *)key);
	return (h_code1(str));
}
int h_code1(char *str) {
	int h=0;
	while(*str)
		h+=*str++;
	return h%HTs;
}
/*** Secondary Hash Function ***/
int hash2(const void *key) {
	char str[MAX];
	strcpy(str, (char *)key);
	return (h_code2(str));
}
int h_code2(char *str) {
	int h=0;
	while(*str)
		h+=*str++;
	return (1+h%(HTs-4));
}
/*** Compare Character ***/
int match_str(const void *key1, const void *key2) {
	return (strcmp((const char *)key1, (const char *)key2) ? 0 : 1);
}

/************************************************************************/
/******************** Open Address Hash Table Source ********************/
/************************************************************************/
int ohtbl_init(OHTbl *htbl, int positions, int (*h1)(const void *key),
			   int (*h2)(const void *key),
			   int (*match)(const void *key1, const void *key2),
			   void (*destroy)(void *data)) {
	int i;
	if((htbl->table=(void **)malloc(sizeof(void *)*positions))==NULL)
		return -1;
	htbl->positions=positions;
	for(i=0; i<htbl->positions; i++)
		htbl->table[i]=NULL;
	htbl->vacated=&vacated;
	htbl->h1=h1;
	htbl->h2=h2;
	htbl->match=match;
	htbl->destroy=destroy;
	htbl->size=0;
	return 0;
}
int ohtbl_lookup(const OHTbl *htbl, void **data) {
	int position, i;
	for(i=0; i<htbl->positions; i++) {
		position=(htbl->h1(*data)+(i*htbl->h2(*data))) % htbl->positions;
		if(htbl->table[position]==NULL)
			return -1;
		else if(htbl->match(htbl->table[position], *data)) {
			*data=htbl->table[position];
			return 0;
		}
	}
	return -1;
}
void ohtbl_destroy(OHTbl *htbl) {
	int i;
	if(htbl->destroy!=NULL)
		for(i=0; i<htbl->positions; i++)
			if(htbl->table[i]!=NULL && htbl->table[i]!=htbl->vacated)
				htbl->destroy(htbl->table[i]);
	free(htbl->table);
	memset(htbl, 0, sizeof(OHTbl));
	return;
}
int ohtbl_remove(OHTbl *htbl, void **data) {
	int position, i;
	printf("Hash status for remove '%s'\n", (char *)*data);
	for(i=0; i<htbl->positions; i++) {
		position=(htbl->h1(*data)+(i*htbl->h2(*data))) % htbl->positions;
		printf("[%02d] ", position);
		if(htbl->table[position]==NULL)
			return -1;
		else if(htbl->table[position]==htbl->vacated)
			continue;
		else if(htbl->match(htbl->table[position], *data)) {
			*data=htbl->table[position];
			htbl->table[position]=htbl->vacated;
			htbl->size--;
			return 0;
		}
	}
	return -1;
}
int ohtbl_insert(OHTbl *htbl, const void *data) {
	void *temp;
	int position, i;
	if(htbl->size==htbl->positions)
		return -1;
	temp=(void *)data;
	if(ohtbl_lookup(htbl, &temp)==0)
		return 1;
	printf("Hashing Status for insertion '%s'\n", (char *)data);
	for(i=0; i<htbl->positions; i++) {
		position=(htbl->h1(data)+(i*htbl->h2(data))) % htbl->positions;
		printf("[%02d] ", position);
		if(htbl->table[position]==NULL || htbl->table[position]==htbl->vacated) {
			htbl->table[position]=(void *)data;
			htbl->size++;
			return 0;
		}
	}
	return -1;
}
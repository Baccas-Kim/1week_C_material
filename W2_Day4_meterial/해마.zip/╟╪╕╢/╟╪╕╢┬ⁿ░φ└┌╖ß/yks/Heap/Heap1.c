#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "heap.h"

#define heap_parent(npos) ((int)(((npos)-1)/2))
#define heap_left(npos)   (((npos)*2)+1)
#define heap_right(npos)  (((npos)*2)+2)

/* sea horse source function prototype */
int  insert_heap(Heap *heap);
void gurndariHeap(Heap *heap);
int  HeapMenu(void);
int  print_heap(Heap *heap);

/* gurndari source function prototye */
int  ginsert_heap(Heap *heap);
int  ginsert(Heap *heap/*, int *size*/, void *data);
void upheap(Heap *heap/*, int size*/);
int  gprint_heap(Heap *heap);
int  gextract_heap(Heap *heap, void **data);
void downheap(Heap *heap, int first);
void gdestroy_heap(Heap *heap);

/* common function */
intcmp(const void *key1, const void *key2);

int INT_MAX=10000;

int main(void) {
	Heap *heap, *gheap;
	if((heap=(Heap *)malloc(sizeof(Heap)))==NULL)
		return -1;
	heap_init(heap, intcmp, free);
	gurndariHeap(heap);
	free(heap);
	return 0;
}
void gurndariHeap(Heap *heap) {
	int select;
	void *data;
	while((select=HeapMenu())!=0) {
		switch(select) {
			case 1 :
				/* sea horse source */
				/* if(insert_heap(heap)!=0)
					printf("Could not insert.\n"); */
				if(ginsert_heap(heap)!=0)
					printf("Could not insert.\n");
				gprint_heap(heap);
				break;
			case 2 :
				/* if(heap_extract(heap, (void **)&data)!=0)
					printf("Could not extract.\n");
				printf("Extracting [%3d]\n", *(int *)data); */
				if(gextract_heap(heap, (void **)&data)!=0)
					printf("Could not extract.\n");
				else
					printf("Extracting [%3d]\n", *(int *)data);
				gprint_heap(heap);
				break;
			case 3 :
				/* if(print_heap(heap)!=0)
					printf("Could not print.\n"); */
				if(gprint_heap(heap)!=0)
					printf("Could not print.\n");
				break;
			case 4 :
				break;
			case 5 :
				/* heap_destroy(heap); */
				gdestroy_heap(heap);
				break;
			case 6 :
				break;
		}
	}
	clrscr();
	printf("Dream of 'Laputa' !\n");
	exit(0);
}
int HeapMenu(void) {
	int select;
	do {
		printf("\nHeap Menu\n");
		printf("1. Heap_Insert\n");
		printf("2. Heap_Extract\n");
		printf("3. Heap_Print\n");
		printf("4. \n");
		printf("5. Heap_Destroy\n");
		printf("6. \n");
		printf("0. Quit\n");
		printf("Select Operation : ");
		scanf("%d", &select);
	} while(select<0||select>6);
	return select;
}
/* insert */
int insert_heap(Heap *heap) {
	void *data;
	if((data=(void *)malloc(sizeof(int)))==NULL)
		return -1;
	printf("Input heap value : ");
	scanf("%d", data);
	if(heap_insert(heap, data)!=0)
		return -1;
	return 0;
}
int print_heap(Heap *heap) {
	int i;
	if(heap->tree==NULL || heap_size(heap)==0)
		return -1;
	printf("Heap size is %d.\n", heap_size(heap));
	for(i=0; i<heap_size(heap); i++)
		printf("[%3d] ", *(int *)heap->tree[i]);
	printf("\n");
	return 0;
}

/* ginsert gextract */
int ginsert_heap(Heap *heap) {
	void *data;
	if((data=(void *)malloc(sizeof(int)))==NULL)
		return -1;
	printf("Input heap value : ");
	scanf("%d", data);
	if(ginsert(heap, data)!=0)
		return -1;
	return 0;
}
int ginsert(Heap *heap, void *data) {
	void *temp;
	if((temp=(void **)realloc(heap->tree, (heap_size(heap)+2)*sizeof(void *)))==NULL)
		return -1;
	else
		heap->tree=temp;
	heap->tree[++heap_size(heap)]=(void *)data;
	upheap(heap);
	return 0;
}
void upheap(Heap *heap) {
	int size;
	void *temp;
	size=heap_size(heap);
	temp=heap->tree[heap_size(heap)];
	heap->tree[0]=&INT_MAX;  /* sentinel */
	while((heap->compare(heap->tree[size/2], temp))!=1) {
		heap->tree[size]=heap->tree[size/2];
		size/=2;
	}
	heap->tree[size]=temp;
}
int gextract_heap(Heap *heap, void **data) {
	void *temp;
	if(heap->tree==NULL || heap_size(heap)==0)
		return -1;
	*data=heap->tree[1];
	heap->tree[1]=heap->tree[heap_size(heap)--];
	if((temp=(void **)realloc(heap->tree, (heap_size(heap)+1)*sizeof(void *)))==NULL)
		return -1;
	else
		heap->tree=temp;
	downheap(heap, 1);
	return 0;
}
void downheap(Heap *heap, int first) {
	int i;
	void *temp;
	temp=heap->tree[first];
	while(first<=heap_size(heap)/2) {
		i=first<<1;
		if(i<heap_size(heap) && (heap->compare(heap->tree[i], heap->tree[i+1]))<0)
			i++;
		if((heap->compare(temp, heap->tree[i]))!=-1)
			break;
		heap->tree[first]=heap->tree[i];
		first=i;
	}
	heap->tree[first]=temp;
}
void gdestroy_heap(Heap *heap) {
	int i;
	if(heap->destroy!=NULL) {
		for(i=0; i<=heap_size(heap); i++) {
			heap->destroy(heap->tree[i]);
		}
	}
	free(heap->tree);
	memset(heap, 0, sizeof(Heap));
	return;
}
int gprint_heap(Heap *heap) {
	int i;
	if(heap->tree==NULL || heap_size(heap)==0)
		return -1;
	printf("Gurndari source.\n");
	printf("Heap size=%d.\n", heap_size(heap));
	for(i=1; i<=heap_size(heap); i++)
		printf("[%3d] ", *(int *)heap->tree[i]);
	printf("\n");
	return 0;
}

/* integer compare */
intcmp(const void *key1, const void *key2) {
	int retval;
	if((retval=*(int *)key1 - *(int *)key2)<0)
		return -1;
	else if(retval>0)
		return 1;
	else
		return 0;
}

/********** Heap **********/
void heap_init(Heap *heap,
			   int (*compare)(const void *key1, const void *key2),
			   void (*destroy)(void *data)) {
	heap->size=0;
	heap->compare=compare;
	heap->destroy=destroy;
	heap->tree=NULL;
	return ;
}
void heap_destroy(Heap *heap) {
	int i;
	if(heap->destroy!=NULL) {
		for(i=0; i<heap_size(heap); i++) {
			heap->destroy(heap->tree[i]);
		}
	}
	free(heap->tree);
	memset(heap, 0, sizeof(Heap));
	return;
}
int heap_insert(Heap *heap, const void *data) {
	void *temp;
	int ipos, /* i=insert position */
		ppos; /* p=parent position */
	if((temp=(void **)realloc(heap->tree, (heap_size(heap)+1)*sizeof(void *)))==NULL) {
		return -1;
	}
	else {
		heap->tree=temp;
	}
	heap->tree[heap_size(heap)]=(void *)data;
	ipos=heap_size(heap);
	ppos=heap_parent(ipos);
	while(ipos>0 && heap->compare(heap->tree[ppos], heap->tree[ipos])<0) {
		temp=heap->tree[ppos];
		heap->tree[ppos]=heap->tree[ipos];
		heap->tree[ipos]=temp;
		ipos=ppos;
		ppos=heap_parent(ipos);
	}
	heap->size++;
	return 0;
}
int  heap_extract(Heap *heap, void **data) {
	void *save, *temp;
	int ipos, lpos, rpos, mpos;
	if(heap_size(heap)==0)
		return -1;
	*data=heap->tree[0];
	save=heap->tree[heap_size(heap)-1];
	if(heap_size(heap)-1>0) {
		if((temp=(void **)realloc(heap->tree, (heap_size(heap)-1)*sizeof(void *)))==NULL) {
			return -1;
		}
		else {
			heap->tree=temp;
		}
		heap->size--;
	}
	else {
		free(heap->tree);
		heap->tree=NULL;
		heap->size=0;
		return 0;
	}
	heap->tree[0]=save;
	ipos=0;
	lpos=heap_left(ipos);
	rpos=heap_right(ipos);
	while(1) {
		lpos=heap_left(ipos);
		rpos=heap_right(ipos);
		if(lpos<heap_size(heap) && heap->compare(heap->tree[lpos], heap->tree[ipos])>0) {
			mpos=lpos;
		}
		else {
			mpos=ipos;
		}
		if(rpos<heap_size(heap) && heap->compare(heap->tree[rpos], heap->tree[mpos])>0) {
			mpos=rpos;
		}
		if(mpos==ipos) {
			break;
		}
		else {
			temp=heap->tree[mpos];
			heap->tree[mpos]=heap->tree[ipos];
			heap->tree[ipos]=temp;
			ipos=mpos;
		}
	}
	return 0;
}

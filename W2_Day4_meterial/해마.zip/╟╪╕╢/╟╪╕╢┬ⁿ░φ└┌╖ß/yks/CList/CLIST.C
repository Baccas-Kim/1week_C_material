#include <stdio.h>
#include <stdlib.h>
#include "clist.h"

#define MAX 20

void StartCList(CList *list);
int CLMenu(void);
int clist_insert(CList *list);
CListElmt *clist_find(CList *list, void *data);
int clist_print(CList *list);
int charcmp(const void *key1, const void *key2);

int main(void) {
	CList *list;
	if((list=(CList *)malloc(sizeof(CList)))==NULL)
		return -1;
	clist_init(list, charcmp, free);
	StartCList(list);
	free(list);
	return 0;
}
void StartCList(CList *list) {
	int select;
	void *temp, *data;
	CListElmt *element;
	while((select=CLMenu())!=0) {
		switch(select) {
			case 1 :
				if(clist_insert(list)!=0)
					printf("Could not insert or Already exist.\n");
				break;
			case 2 :
                if((data=(void *)malloc(sizeof(char)*MAX))==NULL)
					return;
				printf("Input find string : ");
				scanf("%s", data);
				if((element=clist_find(list, data))!=NULL)
					printf("Found %s. !\n", (char *)clist_data(element));
				else
					printf("Could not find.\n");
				list->destroy(data);
				break;
			case 3 :
				if((data=(void *)malloc(sizeof(char)*MAX))==NULL)
					return;
				printf("Input deleting string : ");
				scanf("%s", data);
				if((element=clist_find(list, data))!=NULL) {
					clist_rem_next(list, element, (void **)&temp);
					printf("Next element destroy.\n");
					list->destroy(temp);
				}
				else
					printf("Could not find.\n");
				list->destroy(data);
				break;
			case 4 :
				if(clist_print(list)!=0)
					printf("Could not print.\n");
				break;
			case 5 :
				break;
			case 6 :
				clist_destroy(list);
				break;
		}
	}
	clrscr();
	printf("Dream of 'Lapute' !\n");
	exit(0);
}
int clist_insert(CList *list) {
	void *data;
	if((data=(void *)malloc(sizeof(char)*MAX))==NULL)
		return -1;
	printf("Input string : ");
	scanf("%s", data);
	if(clist_find(list, data)!=NULL) {
		list->destroy(data);
		return -1;
	}
	if(clist_ins_next(list, clist_head(list), data)!=0)
		return -1;
	return 0;
}
CListElmt *clist_find(CList *list, void *data) {
	CListElmt *element;
	element=clist_head(list);
	if(clist_head(list)==NULL || clist_size(list)==0)
		return NULL;
	do {
		if(list->match(data, clist_data(element))!=0)
			element=element->next;
		else
			return element;
	} while(clist_head(list)!=element);
	return NULL;
}
int clist_print(CList *list) {
	CListElmt *element;
	element=clist_head(list);
	if(clist_head(list)==NULL || clist_size(list)==0)
		return -1;
	printf("Circular list size is %d.\n", clist_size(list));
	do {
		printf("%s.\n", clist_data(element));
		element=element->next;
	} while(clist_head(list)!=element);
	return 0;
}
int charcmp(const void *key1, const void *key2) {
	int retval;
	if((retval=strcmp((char *)key1, (char *)key2))<0)
		return -1;
	else if(retval>0)
		return 1;
	else
		return 0;
}
int CLMenu(void) {
	int select;
	do {
		printf("\nCircular Linked List MEMU\n");
		printf("1. clist_ins\n");
		printf("2. clist_find\n");
		printf("3. clist_remove\n");
		printf("4. clist_print\n");
		printf("5. clist_insert_sort\n");
		printf("6. clist_destroy\n");
		printf("0. Quit\n");
		printf("Select Operation : ");
		scanf("%d", &select);
	} while(select<0||select>6);
	return select;
}

/********** Circular List **********/
void clist_init(CList *list,
				int (*match)(const void *key1, const void *key2),
				void (*destroy)(void *data)) {
	list->size=0;
	list->match=match;
	list->destroy=destroy;
	list->head=NULL;
	return;
}
void clist_destroy(CList *list) {
	void *data;
	while(clist_size(list)>0) {
		if(clist_rem_next(list, list->head, (void **)&data)==0 &&
		   list->destroy!=NULL) {
			list->destroy(data);
		}
	}
	memset(list, 0, sizeof(CList));
	return;
}
int clist_ins_next(CList *list, CListElmt *element, const void *data) {
	CListElmt *new_element;
	if((new_element=(CListElmt *)malloc(sizeof(CListElmt)))==NULL)
		return -1;
	new_element->data=(void *)data;
	if(clist_size(list)==0) {
		new_element->next=new_element;
		list->head=new_element;
	}
	else {
		new_element->next=element->next;
		element->next=new_element;
	}
	list->size++;
	return 0;
}
int clist_rem_next(CList *list, CListElmt *element, void **data) {
	CListElmt *old_element;
	if(clist_size(list)==0)
		return -1;
	*data=element->next->data;
	if(element->next==element) {
		old_element=element->next;
		list->head=NULL;
	}
	else {
		old_element=element->next;
		element->next=element->next->next;
	}
	free(old_element);
	list->size--;
	return 0;
}
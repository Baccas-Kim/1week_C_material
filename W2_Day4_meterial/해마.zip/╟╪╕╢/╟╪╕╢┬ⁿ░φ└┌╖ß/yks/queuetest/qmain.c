#include <stdio.h>
#include <string.h>
#include "queue.h"


extern void HeapInit(void);
extern void my_qcreate(int id, int *err);
extern void my_qpost(int id, char *data, int *err, int length);
char* my_qaccept(int id, int *err);

void main(void) {
//	int bOK;
	int err;
	char *b="gurndari", *c="coma", *d="como";
	char *a, *e, *f;
	HeapInit();

    my_qcreate(TX_QID, &err);
	if(err != SRET_OK) {
		dprintf("TX_QID TBuf create fail !!!\r\n");
		return;
	}
	
	my_qcreate(RX_QID, &err);
	if(err != SRET_OK) {
		dprintf("TX_QID RBuf create fail !!!\r\n");
	}

	dprintf("TX_QID & RX_QID Create OK !!!\r\n");

    my_qpost(RX_QID, b, &err, strlen(b));
	if(err!=SRET_OK) {
		dprintf("Could not qpost\n");
		return;
	}
    my_qpost(RX_QID, c, &err, strlen(c));
	if(err!=SRET_OK) {
		dprintf("Could not qpost\n");
		return;
	}
    my_qpost(RX_QID, d, &err, strlen(d));
	if(err!=SRET_OK) {
		dprintf("Could not qpost\n");
		return;
	}

	dprintf("qpost complete operation\n");

	a=my_qaccept(RX_QID, &err);
	if(err!=SRET_OK) {
		dprintf("Could not qaccept\n");
		return;
	}
	e=my_qaccept(RX_QID, &err);
	if(err!=SRET_OK) {
		dprintf("Could not qaccept\n");
		return;
	}
	f=my_qaccept(RX_QID, &err);
	if(err!=SRET_OK) {
		dprintf("Could not qaccept\n");
		return;
	}


	dprintf("qaccept string : %s\n", a);
	dprintf("qaccept string : %s\n", e);
	dprintf("qaccept string : %s\n", f);

	/*Free(d);

	e=my_qaccept(TX_QID, &err);
	if(err!=SRET_OK) {
		dprintf("Could not qaccept\n");
		return;
	}
	dprintf("%s\n", e);*/
}


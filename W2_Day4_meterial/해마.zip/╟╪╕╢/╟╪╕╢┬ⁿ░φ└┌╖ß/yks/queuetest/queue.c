#include <stdio.h>
#include "queue.h"

/* ���� �Լ� ���� ���� */
void dummy_data(void);
char *Malloc(int len);
void Free(char *addr);
void HeapInit(void);
void my_qcreate(int id, int *err);
char *my_qpend(int id, int *err);
char *my_qaccept(int id, int *err);
void my_qpost(int id, char *data, int *err, int length);


/*---------- Memory Allocation ----------*/
static struct mbuf {
   unsigned char buff[MBUFSIZE];	// MBUFSIZE 50
   int status ; 	/* Empty/Full Status Bit */
} Mbuf[MLEN];	// MLEN 50

char *Malloc(int len)  {
	int  i; 
	if (len > MBUFSIZE)  {
		dprintf("Malloc Error !! len = %d \n", len); 
		return(NULL);	
	}

	for(i = 0 ; i < MLEN ;i++)
		if(Mbuf[i].status == EMPTY)  {
			Mbuf[i].status = FULL; 
			break;
		}

	if ( i >= MLEN)  {
		dprintf("Malloc FULL \n");
		return(NULL);
	}
	return((char *)Mbuf[i].buff);
}
/*---------- Memory Allocation ----------*/


void Free(char *addr)  {
	int i;

	for(i = 0 ; i < MLEN ;i++)
		if((unsigned char *)(&Mbuf[i].buff) == (unsigned char *)addr)  {
			Mbuf[i].status = EMPTY; 
			break;
		}

	if ( i >= MLEN)  {
		dprintf("\n Free functions Free Error !!!");
	}
}


void HeapInit(void) {
	int i;
	dprintf("\r\nHeapInit... !!!");
	for(i = 0; i < MLEN; i++)	// MLEN 50
		Mbuf[i].status  = EMPTY;	// EMPTY 0
}


/********************************************************/
/* Queue Handling                                       */
/********************************************************/

/* Functions Prototype */
void my_qcreate(int, int *);
char *my_qaccept(int, int *);
char *my_qpend(int, int *);
void my_qpost(int, char *, int *, int);
void  Bcopy(char *, char *, int );


static unsigned char  rptr[QUEUE_MAX];	 // QUEUE_MAX 2
static unsigned char  wptr[QUEUE_MAX];


/*---------- my_qcreate ----------*/
struct buf_t  {
	unsigned char buff[BUF_SIZE];	// BUF_SIZE 200
	int cnt;
    int status;
} TBuf[RINGS];	// RINGS 30

struct buf_r  {
	unsigned char buff[BUF_SIZE];
	int cnt;
	int status;
} RBuf[RINGS];


void my_qcreate(int id, int *err)  {
   int i;

   switch(id)  {

   case TX_QID :	// TX_QID 1
	   rptr[TX_QID]=wptr[TX_QID]=0;
	   for(i=0; i<RINGS; i++)  {	// RINGS 30
		   TBuf[i].cnt = 0;
		   TBuf[i].status = WRITE;  //WRITE=0x01
       }
	   *err = SRET_OK;
	   break;

   case RX_QID :	// RX_QID 2
       rptr[RX_QID]=wptr[RX_QID]=0;
	   for(i=0; i<RINGS; i++)  {
          RBuf[i].cnt=0;
		  RBuf[i].status = WRITE;
	   }
	   *err = SRET_OK;
	   break;

   default :
	   *err = BUFFER_NODATA;	// BUFFER_NODATA 0x02
	   break;
   }
}
/*---------- my_qcreate ----------*/


char* my_qpend(int id, int *err)  {
    char *ptr;
    int i;

	/* for(;;) */

	switch(id)  {

	case TX_QID:

		dprintf("\r\n TX_QID");



		if(TBuf[rptr[TX_QID]].status == READ)

		{

			dprintf("\r\n [TXQ]READ Status...");

			ptr=(char *)Malloc(TBuf[rptr[TX_QID]].cnt);



            for(i=0; i<TBuf[rptr[TX_QID]].cnt;i++)

				ptr[i]=TBuf[rptr[TX_QID]].buff[i];



           	TBuf[rptr[TX_QID]].cnt = 0; 

			TBuf[rptr[TX_QID]].status = WRITE; 



           	rptr[TX_QID]++ ;



			if (rptr[TX_QID] > RINGS)

				rptr[TX_QID] = 0 ; 

				

			*err = SRET_OK;

			return(ptr);

		}

		else

		{

			dprintf("\r\n TX_QID_qpend No Data..");

			*err = BUFFER_NODATA;

		}

		break;



	case RX_QID:

		 dprintf("\r\nRX_QID");



		 if(RBuf[rptr[RX_QID]].status == READ)

		{

			dprintf("\r\n [RXQ]READ Status ...");	

			ptr = (char *)Malloc(TBuf[rptr[RX_QID]].cnt); 

			for(i = 0 ; i < RBuf[rptr[RX_QID]].cnt; i++)

				ptr[i] = RBuf[rptr[RX_QID]].buff[i];



			RBuf[rptr[RX_QID]].cnt = 0; 

			RBuf[rptr[RX_QID]].status = WRITE; 



			rptr[RX_QID]++ ;



			if (rptr[RX_QID] > RINGS)

					rptr[RX_QID] = 0 ; 

				

			*err = SRET_OK;

			return(ptr);

		}

		else

		{

			dprintf("\r\nRX_QID SC_qpend no data \n");

        			*err = BUFFER_NODATA;

		}

		break;



		default : 

			dprintf("\r\n Qpend QID error=%d", id);  

			break;



	}

	return(NULL);

}


// dequeue(get)
char* my_qaccept(int id, int *err)  {

    char *ptr;
	int i;

	switch(id)  {

	case TX_QID:
		if(TBuf[rptr[TX_QID]].status == READ)  {
			if (TBuf[rptr[TX_QID]].cnt == 0 )  {
				dprintf("\r\n Buffer Size ERROR=%d", rptr[TX_QID]);

			    TBuf[rptr[TX_QID]].cnt = 0; 
				TBuf[rptr[TX_QID]].status = WRITE;

				rptr[TX_QID]++ ;

        		if (rptr[TX_QID] > RINGS)
					rptr[TX_QID] = 0 ;

        		*err = BUFFER_NODATA;

				return(NULL); 
			}

       		ptr = (char *)Malloc(TBuf[rptr[TX_QID]].cnt);

			if ( ptr == NULL)  {
				dprintf("\r\nSC_QACCEPT TX_QID Malloc error");
       			*err = BUFFER_NODATA;
				return(NULL); 
			}

       		for(i = 0 ; i < TBuf[rptr[TX_QID]].cnt; i++)
       			ptr[i] = TBuf[rptr[TX_QID]].buff[i];

       		TBuf[rptr[TX_QID]].cnt = 0;
       		TBuf[rptr[TX_QID]].status = WRITE;

       		rptr[TX_QID]++ ;

       		if (rptr[TX_QID] >= RINGS)
       			rptr[TX_QID] = 0 ;

       		*err = SRET_OK;
       		return(ptr);
        }
		else  {
		    dprintf("\r\nData Number= %d", rptr[TX_QID]);
        	*err = BUFFER_NODATA;
        	return(NULL);
		}
		break;

	case RX_QID :
		if(RBuf[rptr[RX_QID]].status == READ)  {
			if (RBuf[rptr[RX_QID]].cnt == 0 )  {
				dprintf("\r\n Buffer size error %d", rptr[RX_QID]);

      			RBuf[rptr[RX_QID]].cnt = 0; 
				RBuf[rptr[RX_QID]].status = WRITE;

       			rptr[RX_QID]++ ;

       			if (rptr[RX_QID] > RINGS)
					rptr[RX_QID] = 0 ;

       			*err = BUFFER_NODATA;

				return(NULL); 
			}

       		ptr = (char *)Malloc(RBuf[rptr[RX_QID]].cnt);

			if ( ptr == NULL)  {
				dprintf("\r\nSC_QACCEPT TX_QID Malloc error \n");
        		*err = BUFFER_NODATA;
				return(NULL); 
			}

       		for(i = 0 ; i < RBuf[rptr[RX_QID]].cnt; i++) 
				ptr[i] = RBuf[rptr[RX_QID]].buff[i];

	   		RBuf[rptr[RX_QID]].cnt = 0;
       		RBuf[rptr[RX_QID]].status = WRITE;

       		rptr[RX_QID]++ ;

       		if (rptr[RX_QID] >= RINGS)
       			rptr[RX_QID] = 0 ;

       		*err = SRET_OK;
       		return(ptr);
       	}
		else  {
			dprintf("\r\n Buffer no data=%d", rptr[RX_QID]);
			*err = BUFFER_NODATA;
      		return(NULL);
		}
		break;

	default : 
        dprintf("\r\n Qaccept Defualt ...");
		break;
	}
}

// HDCL
#define BUFSIZE	188 

typedef struct data  {
	int length;
	unsigned char  HDLC_Addr;
	unsigned char  HDLC_Ctrl;
	unsigned char  buff[BUFSIZE];
} MPDU;

/* void dummy_data(void)  {
	char k;
	int err;
	int i;
    MPDU *pdu;

	char *temp_test_pointer; */

    /*
	pdu = (MPDU *) Malloc(sizeof(MPDU));
    pdu->length = 192;
    pdu->HDLC_Addr = 0x01;

    pdu->HDLC_Ctrl = 0x93;

             

	for (i=0; i<pdu->length; i++)

	 {

		pdu->buff[i] = 0xff;

     }

    pdu->buff[0] = 0x55;

	pdu->buff[187] = 0x55;

	 */


/*
    for(k=0;k<BUFSIZE;k++)

	{

	   *(temp_test_pointer+k)=(char)k;

	   dprintf("[%03d]", *(temp_test_pointer+k));  

	}

    dprintf("\r\n RXQ ---> post..");

} */

 
// enqueue(put)
void my_qpost(int id, char *data, int *err, int length)  {

	/* MPDU *pdu; */
	/* pdu = (MPDU *)data; */

	if (length > BUFSIZE)  {
		*err = BUFFER_BIG;
		dprintf("buffer big error \n"); 
		Free(data);
		return ; 
	}

	switch(id) 	{

	case TX_QID : /* application task ==> TX interrupt service routine */ 
		if(TBuf[wptr[TX_QID]].status != WRITE)  {
		    dprintf("\r\n Buffer Full=%d", wptr[TX_QID]);
			Free(data);
			return ;  
		}

		/* Bcopy((char *)pdu->buff,(char *)TBuf[wptr[TX_QID]].buff,pdu->length); */
		// Bcopy(a, b, length) : a-source, b-destination ; Byte copy
		Bcopy((char *)data, (char *)TBuf[wptr[TX_QID]].buff, length);

		TBuf[wptr[TX_QID]].cnt = length; 
		TBuf[wptr[TX_QID]].status = READ; 

		wptr[TX_QID]++ ;

		if(wptr[TX_QID] >= RINGS)
			wptr[TX_QID] = 0 ; 

		*err = SRET_OK ; 
		break;

	case RX_QID :  /* interrupt service routine : TX HDLC ==> application */
		if(RBuf[wptr[RX_QID]].status != WRITE)  {
			//*err = BUFFER_FULL;
			dprintf("\\r\n Buffer read error",wptr[RX_QID]);   
			Free(data);
			return ;  
		}

		Bcopy((char *)data, (char *)RBuf[wptr[RX_QID]].buff, length);

		RBuf[wptr[RX_QID]].cnt = length; 
		RBuf[wptr[RX_QID]].status = READ; 

		wptr[RX_QID]++ ; 

		if(wptr[RX_QID] >= RINGS) 
			wptr[RX_QID] = 0 ; 

		*err = SRET_OK ; 
		break;	

	default : 
		dprintf("\r\n qpost error=%d", id);
		*err = BUFFER_NODATA ; 
		break;
	}
	/* Free(data); */ /* ??? */ 
	return; 
}

// Byte Copy
void Bcopy(char *p1, char *p2, int len)  {
	register int i ; 
	for(i = 0 ; i < len ; i++)
		p2[i] = (unsigned char )p1[i] ;  
}
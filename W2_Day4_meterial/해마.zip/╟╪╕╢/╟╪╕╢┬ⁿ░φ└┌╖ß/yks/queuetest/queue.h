#define MLEN 50
#define MBUFSIZE 50
#define EMPTY 0 
#define FULL  1 

//#define NULL 0

/* Define Definition Area */

/* ������ Queue�� ���� ID�� ���� ���ش� */
#define TX_QID          1
#define RX_QID          2
#define RINGS           30
#define BUF_SIZE        200

#define WRITE           0x01
#define READ            0x02

#define SRET_OK         0x01
#define RET_OK          0x00
#define BUFFER_NODATA   0x02
#define BUFFER_BIG      0x03
#define BUFFER_FULL     0x04
#define QUEUE_MAX		3


#define dprintf printf
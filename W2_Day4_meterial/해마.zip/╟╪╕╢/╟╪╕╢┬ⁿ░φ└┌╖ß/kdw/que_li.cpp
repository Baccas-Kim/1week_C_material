#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include"list.h"
#include"queue.h"

void save_queue(Queue *queue,char *a)
{
	FILE *fp;
	QueueElmt *element;
	element = queue_head(queue);
	if((fp=fopen(a,"wb"))== NULL)
	{
		printf("\nError : Not exist file");
		return;
	}
        while(element != NULL)
	{
		fwrite(element,MAX,1,fp);
		element = queue_next(element);
	}
	fclose(fp);
        return;
}

void inter_tran(Queue *queue,char *b)
{
      int i;
      printf("\n ==Data is transmitting to the File==");
      save_queue(queue,b);
      printf("\n Do you want Queue init==> yes(1)||no(0)");
      scanf("%d",&i);
      if(i == 1)
      {
	queue_destroy(queue);
	if((queue = (Queue *)malloc(sizeof(Queue))) == NULL)
	{    
		printf("\n Error");
		return;
	}
        else
	queue_init(queue,free);
      	return;
      }
      else 
      return;

}

int queue_enqueue(Queue *queue,const void *data)
{
	return list_ins_next(queue,list_tail(queue),data);
}

int queue_dequeue(Queue *queue, void **data)
{
	return list_rem_next(queue,NULL,data);
}


void list_destroy(List *list)
{
	void *data;
	while(list_size(list) > 0)
	{
		if(list_rem_next(list, NULL, (void **)&data) == 0 && list->destroy != NULL)

		{
			list->destroy(data);
		}
	}
	memset(list,0,sizeof(List));
	return;
}


int list_ins_next(List *list, ListElmt *element, const void *data)
{
	ListElmt *new_element;
	if((new_element = (ListElmt *)malloc(sizeof(ListElmt))) == NULL)
		return -1;

	strcpy(new_element->data,(char *)data);
        
        if(element == NULL)
	{

		if(list_size(list) == 0)
			list->tail = new_element;

		new_element->next = list->head;
		list->head = new_element;
	}
	else{
		if(element->next == NULL)
			list->tail = new_element;
		new_element->next = element->next;
		element->next = new_element;
	}

	list->size++;
	return 0;
}



int list_rem_next(List *list,ListElmt *element,void **data)
{
	ListElmt *old_element;

	if(list_size(list) == 0)
		return -1;

	if(element == NULL)
	{
                printf("\n \t HEAD");
		strcpy((char *)data,list->head->data);
		old_element = list->head;
		list->head = list->head->next;
		if(list_size(list) == 0)
			list->tail = NULL;
	}

	else {
		if(element->next == NULL)
			return -1;

                strcpy((char *)data,element->next->data);
		old_element = element->next;
		element->next = element->next->next;

		if(element ->next == NULL)
			list->tail = element;
	      }

		free(old_element);
		list->size--;


		return 0;
}


void print_queue(Queue *queue)
{
	QueueElmt *print;
	printf("\n printing  from front to rear ==> "); 
	for(print = queue_head(queue); print!= NULL; print = queue_next(print))
		printf("\t %s",queue_data(print));
	return;
}

void menu_print(int *a)
{
	printf("\n ===========QUEUE===========");
	printf("\n\t1. enqueue ");
	printf("\n\t2. dequeue ");
	printf("\n\t3. print");
	printf("\n============================");
	printf("\nEnter to  choice number ==>");
	do{
		scanf("%d",a);
	}while(*a < 0 || *a > 5);
}

void list_init(List *list, void (*destroy)(void *data))
{
	list->size = 0;
        list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;
	return;
}

void main(void)
{
	int b;
	char *pa;
        char *a = "QU_LI.DAT";
	Queue *queue;
        QueueElmt *element;
	if((queue=(Queue *)malloc(sizeof(Queue)))== NULL)
	{
		printf("\n Error : it is to fail with memory allocation");
		return;
	}
        queue_init(queue,free);
	for(;;)
	{
		if(queue_size(queue) > 4)
		{
			inter_tran(queue,a);
		}
                else
                menu_print(&b);
		switch(b)
		{
			case 1:
				printf("\n enter to insert data==>");
				scanf("%s",pa);
				queue_enqueue(queue,pa);
				break;
			case 2:
				printf("\n dequeue ");
				if((queue_dequeue(queue,(void **)&pa)) == -1)
				{
					printf("\n Queue underflower");
					if((queue = (Queue *)malloc(sizeof(Queue))) == NULL)
					{
						printf("\n Error: it is to fail with memory allocation");
						break;
                                        }
                                        else
					queue_init(queue,free);
					break;
				}
                                else
                                	printf("\n dequeue data ==> %s",&pa);
				break;
			case 3:
				print_queue(queue);
				break;
			default :
				printf("\n========= choice again ======");
				break;
		}
        }
}
#include<stdio.h>

#include<string.h>
#include<stdlib.h>


char *char_to_binary(int);

main(int argv,char *argc[])
{
	int ch;
	int letter = 0;

	unsigned int line = 1;
	FILE *fp;

	if(argv != 2)
	{
		printf("\nProper Usage is : ");
		printf("\n %s in_file",argc[0]);
		printf("\nbye....");
		exit(1);
	}
	if((fp = fopen(argc[1], "r")) == NULL)
	{
		printf("\nError Opening file : %s ",argc[1]);
		exit(1);
	}
	printf("\n %5.5d:",line);

	while((ch = fgetc(fp)) != EOF)
	{
		printf("%s ",char_to_binary(ch));

		if(ch == '\n')
		{
			line ++;
			letter = 0;
			printf("\n %5.5d",line);
		}
		else
		{
			if(++letter >= 7)
			{
				printf("\n");
				letter = 0;
			}
		}
	}
	fclose(fp);
	return(0);
}


char * char_to_binary(int ch)
{
	int ctr;
	char *binary_string;
	int bitstatus;

	if((binary_string = (char *)malloc(9*sizeof(char)))==NULL)
	{
		printf("\nunsucessful");
	}
	else
	{
	for(ctr=0;ctr<8;ctr++)
	{
		switch(ctr)
		{
			case 0:
				bitstatus = ch & 128;
				break;
			case 1:
				bitstatus = ch & 64;
				break;
			case 2:
				bitstatus = ch & 32;
				break;
			case 3:
				bitstatus = ch & 16;
				break;
			case 4:
				bitstatus = ch & 8;
				break;
			case 5:
				bitstatus = ch & 4;
				break;
			case 6:
				bitstatus = ch & 2;
				break;
			case 7:
				bitstatus = ch &1;
				break;
		}
		binary_string[ctr]=(bitstatus) ? '1' :'0';
	}
	binary_string[8] =0;
	return (binary_string);
	}
}


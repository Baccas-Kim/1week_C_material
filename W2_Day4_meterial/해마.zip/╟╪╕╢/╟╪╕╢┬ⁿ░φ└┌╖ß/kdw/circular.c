#include<stdlib.h>
#include<stdio.h>
#include<string.h>



typedef struct CListElmt_ {
	void *data;
	struct CListElmt_ *next;
	}CListElmt;

typedef struct CList_ {
	int size;
	int (*match)(const void *key1, const void *key2);
	void (*destroy)(void *data);

	CListElmt *head;
	}CList;



void clist_init(CList list, void (*destroy)(void *data));
void clist_destroy(CList *list);
int clist_ins_next(CList *list,CListElmt *element,const void *data);
int clist_rem_next(CList *list,CListElmt *element,void **data);
void menu_print(void);
void print(CList *list);
CListElmt *find(CListElmt *element,int nu);

#define clist_size(list) ((list)->size)
#define clist_head(list) ((list)->head)
#define clist_data(element) ((element)->data)
#define clist_next(element) ((element)->next)

void clist_init(CList *list, void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	return ;
}


int clist_ins_next(CList *list,CListElmt *element ,const void *data)
{
	CListElmt *new_element;

	if((new_element = (CListElmt *)malloc(sizeof(CListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;

	if(clist_size(list) == 0)
	{
		new_element->next = new_element;
		list->head = new_element;
	}
	else{
		new_element->next = element->next;
		element->next = new_element;
	}
	list->size++;

	return 0;
}

int clist_rem_next(CList *list,CListElmt *element, void **data)
{
	CListElmt *old_element;

	if(clist_size(list) == 0)
		return -1;

	*data = element->next->data;
	if(element->next == element)
	{
		old_element = element->next;
		list->head = NULL;
	}
	else
	{
		old_element = element->next;
		element->next = element->next->next;
	}

	free(old_element);
	list->size--;
	return 0;
}

void clist_destroy(CList *list)
{
	void *data;

	while(clist_size(list)>0)
	{
		if(clist_rem_next(list,list->head,(void**)&data)==0 && list->destroy != NULL)
		{
			list->destroy(data);
		}
	}
	memset(list,0,sizeof(CList));
	return ;
}

void print(CList *list)
{
	CListElmt *element;
	element = clist_head(list);
        printf("\n print HEAD === >");
	while(clist_head(list) != clist_next(element))
	{
		printf("\t %d",clist_data(element));
		element = clist_next(element);
	}
	printf("\t %d",clist_data(element));
}

CListElmt *find(CListElmt *element,int nu)
{
	int i;
	for(i=1;i<nu;i++)
		element = clist_next(element);
	return element;
}


void menu_print(void)
{
	printf("\n==========circular simple linked list===========");
	printf("\n \t1. clist_insert_next");
	printf("\n \t2. find_clist_insert_next");
	printf("\n \t3. clist_rem_next");
	printf("\n \t4. find_clist_rem_next");
	printf("\n \t5. clist_destroy");
	printf("\n \t6. print");
	printf("\n \t7.exit");
	printf("\n================================================\n");
}


void main(void)
{
	void *da;
	CList *list;
	CListElmt *find_element;
        int nu;
	int ch;
	clist_init(list,free);
	for(;;)
	{
		menu_print();
                printf("\n enter choice number ==> ");
                scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("\n input data ===> ");
				scanf("%d",&da);
				clist_ins_next(list,clist_head(list),da);
				break;
			case 2:
				printf("\n input  number of finding data==>");
				scanf("%d",&nu);
				find_element = find(clist_head(list),nu);
				printf("\n finding Succesful");
				printf("\n input next data ==>");
				scanf("%d",&da);
				clist_ins_next(list,find_element,da);
				break;
			case 3:
				printf("\n delete only one from head");
				clist_rem_next(list,clist_head(list),(void **)&da);
				break;
			case 4:
				printf("\n input number of finding data==>");
				scanf("%d",&nu);
				find_element = find(clist_head(list),nu);
				printf("\n finding Succesful");
				printf("\n delete next to find data");
				clist_rem_next(list,find_element,(void **)&da);
				break;
			case 5:
				printf("\n ALL linked list free");
				clist_destroy(list);
                                break;
			case 6:
				print(list);
				break;
			case 7:
				exit(1);
			default :
				printf("\nTo again choice");
				break;
		}
	}
}


				 

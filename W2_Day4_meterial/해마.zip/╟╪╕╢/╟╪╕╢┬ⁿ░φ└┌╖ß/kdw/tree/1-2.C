
#include<stdio.h>
#include<stdlib.h>


struct tree{
		char info[20];
		int cnt;
		struct tree *left,*right;
}*root;

FILE *in,*out;
void insert(char *);
int strcomp(char *,char *);
void strcopy(char *, char *);
void inorder(struct tree *);


void main()
{
	char value[20];
		printf("\n=============================");
		printf("\nTree Test algorithms");
		printf("\n=============================");



	if((in = fopen("a:\word.dat","r"))==NULL)
	{
		printf("\n 1.none successful");
	}
	if((out= fopen("freq.out","w"))==NULL)
	{
		printf("\n 2.none successful");
	}
	while(fscanf(in,"%s",value),(strcomp(value,"/*") != 0))
	insert(value);

	printf("\nfreq.out .............saved");
	fprintf(out,"\t Word \t\t    Frequencies\n");
	inorder(root);
	fclose(in);
	fclose(out);
printf("\n");
}


int strcomp(char str1[20],char str2[20])
{
	int i;
	for(i=0;str1[i] == str2[i];i++)
	{
		if(str1[i] == '\0')
		{
			return 0;
		}
	}
	if(str1[i]<str2[i])
		return -1;
	else 	return 1;
}

void strcopy(char *str1,char *str2)
{
	for(;*str1 = *str2;str1++,str2++)
	;
}


void insert(char val[20])
{
	static struct tree *newnode, *p, *back;

	newnode = (struct tree *)malloc(sizeof *root);
	newnode->left = 0;
	newnode->right =0;
		strcopy(newnode->info,val);
		newnode->cnt=1;
		p=root;
	back =0;
		while(p != 0)
		{
		back = p;
			if(strcomp(p->info,val) == 1)
			{
				p=p->left;
			}
			else if(strcomp(p->info,val) == -1)
			{
				p = p->right;
			}
			else
			{
				p->cnt++;
				break;
			}
		}
		if(back == 0)
		{
			root = newnode;
		}
		else if(strcomp(back->info,val) == 1)
		{
			back->left = newnode;
		}
		else if(strcomp(back->info,val) == -1)
		{
			back->right=newnode;
		}
}

void inorder(struct tree *p)
{
	if(p != 0)
	{
		inorder(p->left);
		fprintf(out,"\t %-20s:  %5d\n",p->info,p->cnt);
	}
}

#include<stdio.h>

#define MAX 10
int stack[MAX];
int top;

void initial(void)
{
	top=-1;
}


int push(int k)
{
	if(top>=MAX-1)
	{
		printf("\nover flower");
		return;
	}
	stack[++top] = k;
	printf("\ntop==> %d input==>%d",top,stack[top]);
	return k;
}

int pop()
{

	if(top<0)
	{
		printf("\nunder flower");
		return;
	}
	return stack[top--];
}

void print_all()
{
	int k;
	for(k=0;k<=top;k++)
	{
		printf("\nstack[%d]==> %d",k,stack[k]);
	}
}
void menu_print()
{
	printf("\n=============stack=============");
	printf("\n\t1.push");
	printf("\n\t2.pop");
	printf("\n\t3.print_all");
	printf("\n\t4.exit");
	printf("\n===============================");


}
void main(void)
{
	int ch;
	int data;
	initial();
	while(1)
	{
		menu_print();
		printf("\ninput stack menu==>");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				{
					printf("\ninput push data ==> ");
					scanf("%d",&data);
					push(data);
				}break;
			case 2:
				{
					data=pop();
					printf("\npop==> %d",data);
				}break;
			case 3:
				{
					print_all();
				}break;
			case 4:
				exit(1);
			default:
					printf("\nagain input stack menu");
				break;
		}
	}
}
#include<stdio.h>
#include<alloc.h>
#include<stdlib.h>

typedef struct _stack{
				   int key;
				   struct _stack *next;
				}stack;
stack *head,*tail;


void initial_stack()
{
	head =(stack *)malloc(sizeof(stack));
	tail =(stack *)malloc(sizeof(stack));
	head->next=tail;
	tail->next=tail;
}

void push(int k)
{
	stack *p;
	if((p =(stack *)malloc(sizeof(stack)))==NULL)
	{
		printf("\nout of memory");
		return;
	}
	p->key=k;
	p->next = head->next;
	head->next = p;
}
void pop()
{
	stack *p;
	p=head->next;
	if(p==tail)
	{
		printf("\n\t\tunder flower");
		return ;
	}
	printf("\n\t\tpop data==>%d",p->key);
	head->next=p->next;
	free(p);
}
void print_all()
{
	stack *p;
	p = head->next;

	while(p != tail)
	{
		printf("\n\t\t print data==> %d",p->key);
		p=p->next;
	}

}
void clear_stack()
{
	stack *p;
	stack *o;
	p=head->next;
	while(p != tail)
	{
		o=p;
		p=p->next;
		free(o);
	}
	head->next=tail;

}
void menu_print()
{
	printf("\n=====stack use of simple linked list=====");
	printf("\n\t1.push");
	printf("\n\t2.pop");
	printf("\n\t3.print");
	printf("\n\t4.clear");
	printf("\n\t5.exit");
	printf("\n=========================================");
}

void main(void)
{
	int c;
	int data;
	initial_stack();
	while(1)
	{
		menu_print();
		printf("\ninput stack menu==>");
		scanf("%d",&c);
		switch(c)
		{
			case 1:
			{
				printf("\ninput push data==>");
				scanf("%d",&data);
				push(data);
			}break;
			case 2:
			{
				printf("\nyou want to pop ");
				pop();
			}break;
			case 3:
			{
				printf("\nyou want to print");
				print_all();
			}break;
			case 4:
			{
				printf("\nclear stack");
				clear_stack();

				}break;

			case 5:
				exit(1);
			default:
				printf("\nagain input stack menu");
				break;
		}
	}
}

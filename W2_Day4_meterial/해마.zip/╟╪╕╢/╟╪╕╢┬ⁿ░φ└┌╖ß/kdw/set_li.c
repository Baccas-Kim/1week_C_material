#include <stdlib.h>
#include<stdio.h>                                                                                                                                                                                                                                                                                                                                          #include<string.h>

#include "stack.h"
#include "list.h"
#include "set.h"

/*============================== funtion pointer ==========================*/
void (*pri_handler)(Set *);
int (*inse_handler)(Set *, const void *);
//int (*set_se_handler)(const Set *, const Set *);
/*=========================================================================*/

void list_init(List *list,void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;
	return ;

}

void set_init(Set *set, int (*match)(const void *key1, const void *key2), void (*destroy)(void *data))
{

	list_init(set, destroy);
	set->match = match;

	return;
}

int compare(const void *key1, const void *key2)
{
	return ((key1 == key2) ?  1 : 0);
}

int set_insert(Set *set, const void *data)
{
	if(set_is_member(set,data))
		return -1;
	return list_ins_next(set, list_tail(set), data);
}

int set_is_member(const Set *set, const void *data)
{
	ListElmt *member;
	for(member = list_head(set) ; member != NULL ; member = list_next(member))
	{
		if(set->match(data,list_data(member)))
			return 1;
	}
	return 0;
}

int list_ins_next(List *list, ListElmt *element, const void *data)
{
	ListElmt *new_element;
	if((new_element = (ListElmt *)malloc(sizeof(ListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;

	if(element == NULL)
	{

		if(list_size(list) == 0)
			list->tail = new_element;

		new_element->next = list->head;
		list->head = new_element;
	}
	else{
		if(element->next == NULL)
			list->tail = new_element;
		new_element->next = element->next;
		element->next = new_element;
	}

	list->size++;
	return 0;
}

int list_rem_next(List *list, ListElmt *element, void **data)
{
	ListElmt *old_element;

	if(list_size(list) == 0)
		return -1;
	if(element == NULL)
	{
		*data = list->head->data;
		old_element =list->head;
		list->head = list->head->next;

		if(list_size(list) == 0)
			list->tail = NULL;
	}

	else
	{
		if(element->next == NULL)
			return -1;
		*data = element->next->data;
		old_element = element->next;
		element->next = element->next->next;
		if(element->next == NULL)
			list->tail = element;
	}
	free(old_element);
	list->size--;
	return 0;
}


void list_destroy(List *list)
{
	void *data;
	while(list_size(list) > 0)
	{
		if(list_rem_next(list, NULL, (void **)&data ) == 0 && list->destroy != NULL)
		{
			list->destroy(data);
		}
	}
	memset(list, 0, sizeof(List));
	return;
}

int set_remove(Set *set, void **data)
{
	ListElmt *member, *prev;
	prev = NULL;
	for(member = list_head(set); member != NULL; member = list_next(member))
	{
		if(set->match(*data, list_data(member)))
			break;

		prev = member;
	}

	if(member == NULL)
		return -1;

	return list_rem_next(set,prev,data);
}


void menu_print()
{
	printf("\n ============SET_linked list============");
	printf("\n \t 1. set1 _ insert");
	printf("\n \t 2. set2_insert");
	printf("\n \t 3. set_union");
	printf("\n \t 4. intersection");
	printf("\n \t 5. set_print");
	printf("\n \t 6. exit");
	printf("\n =======================================");
}

void set_print(Set *set)
{
	ListElmt *element;
	printf("\n PRINT from head to tail ==> ");
	for(element=list_head(set); element != NULL; element = list_next(element))
			printf("\t %d", list_data(element));
	return;
}

int set_union(Set *setu, const Set *set1, const Set *set2)
{
	ListElmt *member;
	void *data;

	set_init(setu, set1->match, NULL);

	for(member = list_head(set1); member != NULL; member = list_next(member))
	{
		data = list_data(member);

		if(list_ins_next(setu, list_tail(setu), data) != 0)
		{
			set_destroy(setu);
			return -1;
		}
	}

	for(member = list_head(set2); member != NULL; member = list_next(member))
	{
		if(set_is_member(set1, list_data(member)))
		{
			continue;
		}
		else
		{
			data = list_data(member);
			if(list_ins_next(setu, list_tail(setu), data) != 0)
			{
				set_destroy(setu);
				return -1;
			}
		}
	}
	return 0;
}

int set_intersection(Set *seti, const Set *set1, const Set *set2)
{
	ListElmt *member;
	void *data;

	set_init(seti, set1->match, NULL);
	for(member = list_head(set1); member != NULL; member = list_next(member))
	{
		if(set_is_member(set2, list_data(member)))
		{
			data = list_data(member);
			if(list_ins_next(seti, list_tail(seti), data) != 0)
			{
				set_destroy(seti);
				return -1;
			}
		}
	}
	return 0;
}

int set_is_subset(const Set *set1, const Set *set2)
{
	ListElmt *member;

	if(set_size(set1)>set_size(set2))
		return 0;
	for(member = list_head(set1); member != NULL; member = list_next(member))
	{
		if(!set_is_member(set2, list_data(member)))
			return 0;
	}

	return 1;
}



void main(void)
{
	int *da;
	Set *set1, *set2;
	Set setu, seti;
	Set *array[MAX];
	int count = -1;
	int nu;
	int n;
	if((set1 = (Set *)malloc(sizeof(Set))) == NULL)
	{
		printf("\n Error : It is to fail of the memory allocation");
		return ;
	}
	if((set2 = (Set *)malloc(sizeof(Set))) == NULL)
	{
		printf("\n Error : It is to fail of the memory allocation");
		return;
	}
	set_init(set1, compare, free);
	set_init(set2, compare, free);
	array[++count] = set1;
	array[++count] = set2;
	array[++count] = &setu;
	array[++count] = &seti;
	for(;;)
	{
		pri_handler = set_print;
		inse_handler = set_insert;
		menu_print();
		printf("\n seleting number==> ");
		scanf("%d",&nu);
		switch(nu)
		{
			case 1:
				printf("\n========= Insert ==========");
				printf("\n Input data ==> ");
				scanf("%d",&da);
				printf("\n choice  space number ");
				printf("\n 1. set1 \t 2. set2");
				scanf("%d",&n);
				if(inse_handler(array[n-1],da) == 1)
				{
					printf("\n Already exist that your input data ");
					break;
				}
				printf("\n Succesful inserting data");
				break;
			case 2:
				printf("\n========= Union ===========");
				if(set_union(setu,set1,set2) != 0)
				{
					printf("\nError : Not exist data");
					break;
				}
				printf("\n Succesful");
				break;
			case 3:
				printf("\n======== intersection =======");
				if(set_intersection(&seti, set1, set2) != 0)
				{
				       printf("\n Error : Not exist data");
				       break;
				}
				printf("\n Succesful");
				break;
			case 4:
				printf("\n======== subset =========");
				if(set_is_subset(set1, set2) == 0)
				{
					printf("\n Error : set1 is not subset to the set2");
					break;
				}
				printf("\n Succesful subset ");
				break;

			case 5:
				printf("\n choice printing number==> ");
				printf("\n 1. set1 \t 2. set2 \t 3. setu \t 4.seti==>");
				scanf("%d",&n);
				pri_handler(array[n-1]);
				break;
			case 6:
				exit(1);
			default :
				printf("\n choice again");
				break;

		}
	}
}


































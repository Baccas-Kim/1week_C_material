#include<stdio.h>
#include<stdlib.h>
#include"sim-fun.h"


void main(void)
{
	int menu_input,data,ta;
	node *s,*p,*o,*u;
	init_list();
	for(;;)
	{
		menu_print();
		printf("\ninput choise number ==>");
		scanf("%d",&menu_input);
	      	switch(menu_input)
		{
			case 1:
			{
				printf("\ninput data ==>");
				scanf("%d",&data);
				s = ordered_insert(data);
				printf("input ==> %d",s->key);
				print_list(head->next);
			}break;
			case 2:
			{
				printf("\ninput before data==>");
				scanf("%d",&data);
				printf("\ninput after data==>");
				scanf("%d",&ta);
				printf("\ninserting %d before %d",data,ta);
				insert_node(data,ta);
				printf("\ninserting %d before %d",data,ta);
			}break;

			case 3:
			{
				printf("\ninput find before data==>");
				scanf("%d",&data);
				p = find_node(data);
				printf("\ninput after data==>");
				scanf("%d",&ta);
				printf("\ninserting %d after %d",ta,data);
				insert_after(ta,p);
			}break;
			case 4:
			{
				printf("input delet data==>");
				scanf("%d",&data);
				o=find_node(data);
				if(delete_next(o))
					printf("\ndeleting %d is successful");
			}break;
			case 5:
			{
				printf("\ninput find data ==>");
				scanf("%d",&data);
				u = find_node(data);
				printf("\n %d is finding",u->key);
			}break;
			case 6:
			{
			       printf("\ninput delete data==> ");
			       scanf("%d",&data);
			       delete_node(data);
			}break;
			case 7:
			{
				printf("\nprinting from head->next");
				print_list(head->next)
                        }break;
			case 8:
			{
				printf("all delete");
				delete_all();
			}break;
			case 9:
				exit(1);
			default:
				printf("this program is doing from 0 to 9");
		}
	}
}

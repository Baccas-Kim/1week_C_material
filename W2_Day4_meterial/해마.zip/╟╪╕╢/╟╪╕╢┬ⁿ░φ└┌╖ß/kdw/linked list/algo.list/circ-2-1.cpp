#include<stdlib.h>
#include<stdio.h>
#include<string.h>


#define MAX 50

typedef struct CListElmt_ {
	char data[MAX];
	struct CListElmt_ *next;
	}CListElmt;

typedef struct CList_ {
	int size;
	int (*match)(const void *key1, const void *key2);
	void (*destroy)(void *data);

	CListElmt *head;
	}CList;



void clist_init(CList list, void (*destroy)(void *data));
void clist_destroy(CList *list);
int clist_ins_next(CList *list,CListElmt *element,const void *data);
int clist_rem_next(CList *list,CListElmt *element,void **data);
void menu_print(void);
void print(CList *list);
CListElmt *find(CList *list,void *da);
CListElmt *move_pivot(CListElmt *element,int nu);
CListElmt * big_size_find(CList *list,void **da);

#define clist_size(list) ((list)->size)
#define clist_head(list) ((list)->head)
#define clist_data(element) ((element)->data)
#define clist_next(element) ((element)->next)

CListElmt *move = NULL;


void clist_init(CList *list, void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	return ;
}
/*int clist_ins_next(CList *list,CListElmt *element ,const void *data)
{
	CListElmt *new_element;

	if((new_element = (CListElmt *)malloc(sizeof(CListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;

	if(clist_size(list) == 0)
	{
		new_element->next = new_element;
		list->head = new_element;
	}
	else{
		new_element->next = element->next;
		element->next = new_element;
	}
	list->size++;

	return 0;
} */

int clist_ins_next(CList *list,CListElmt *element ,const void *data)
{
	CListElmt *new_element;
        CListElmt *head;
	if((new_element = (CListElmt *)malloc(sizeof(CListElmt))) == NULL)
		return -1;

	strcpy(new_element->data,(char *)data);
	if(element == NULL)
	{
		if(clist_size(list) == 0)
                {
                	new_element->next = new_element;
			list->head = new_element;
                 	move = new_element;
                	printf("\n move data ==> %s",clist_data(move));
		}
		else
                {
                        move->next = new_element;
			new_element->next = list->head;
			move = new_element;
                }  
        }
	else{
		if(element == move)
                {
			element->next = new_element;
			new_element->next = list->head;
			move = new_element;
                }
                else	
		new_element->next = element->next;
		element->next = new_element;
	}
	list->size++;

	return 0;
}

int clist_rem_next(CList *list,CListElmt *element, void **data)
{
	CListElmt *old_element;

	if(clist_size(list) == 0)
		return -1;

	*data = element->next->data;
	if(element->next == element)
	{
		old_element = element->next;
		list->head = NULL;
	}
	else
	{
		old_element = element->next;
		element->next = element->next->next;
	}

	free(old_element);
	list->size--;
	return 0;
}
/*

int clist_rem_next(CList *list,CListElmt *element, void **data)
{
	CListElmt *old_element;

	if(clist_size(list) == 0)
		return -1;
	 strcpy((char *)*data,clist_data(element));
	if(element == list->head)
	{
		if(element == clist_next(element))
		{
			old_element = element;
			list->head =NULL;
			move = NULL;
                }
		else
		{

                	old_element = element ;
                	move->next = element->next;
			list->head = element->next;
                }
	}
	else
	{       
		old_element = element->next;
		element->next = element->next->next;
	}

	free(old_element);
	list->size--;
	return 0;
}
   */
void clist_destroy(CList *list)
{
	void *data;

	while(clist_size(list)>0)
	{
		if(clist_rem_next(list,list->head,(void**)&data)==0 && list->destroy != NULL)
		{
			list->destroy(data);
		}
	}
	memset(list,0,sizeof(CList));
	return ;
}

void print(CList *list)
{
	CListElmt *element;
        element = clist_head(list);
	printf("\n print HEAD === >");
	if(element == NULL)
	{
		printf("\n None exist list ");
		return;
	}
	if(element == clist_next(element))
	{
		printf("\t %s",clist_data(element));
		return;
        }
        else
        while(clist_next(element) != clist_head(list))
	{
                
               
		printf("\t %s",clist_data(element));
		element = clist_next(element);
	} 
        printf("\t %s",clist_data(element));
}


CListElmt *move_pivot(CListElmt *element,int nu)
{
        while(nu>1)
	{
		element = clist_next(element);
		nu--;
	}
        return element;
}
CListElmt * big_size_find(CList *list,void **da)
{
        int n;
	CListElmt *element;
	CListElmt *pivot_element;
        element = clist_head(list);
	pivot_element = clist_head(list);
	/*if((clist_size(list)%2) != 0)
	{
		n = (clist_size(list)/2)+1;
	}*/
       	n = clist_size(list)/2;
	
	printf("\npivot number ==>  %d",n);
        pivot_element = move_pivot(pivot_element,n);
	while(pivot_element != clist_head(list))
	{
		if(strcmp(clist_data(element),(char *)*da)== 0)
		{
			printf("\n %s is finded by head ",clist_data(element));
      			return element;
		}
		else if(strcmp(clist_data(pivot_element),(char *)*da)==0)
		{	
			printf("\n %s is finded by pivot",clist_data(pivot_element));
			return pivot_element;
		}
		element=clist_next(element);
		pivot_element=clist_next(pivot_element);
	}
	 return NULL;
}
CListElmt *find(CList *list,void *da)
{
	CListElmt  *element;
	CListElmt  *pivot_element;
	CListElmt *pivot;
        int n;
	element = clist_head(list);
        if(clist_size(list)<5)
        {
                while(element != clist_next(element))
		{
			if(strcmp(clist_data(element),(char *)da) == 0)
			{

                                printf("\n finding from head ==> %s",clist_data(element)); 
				return element;
			}
			element = clist_next(element);
		}
		return NULL;
	}
	else
	{

		return big_size_find(list,(void **)&da);

        }
}

void menu_print(void)
{
	printf("\n==========circular simple linked list===========");
	printf("\n \t1. clist_insert_next");
	printf("\n \t2. find_clist_insert_next");
	printf("\n \t3. clist_rem_next");
	printf("\n \t4. find_clist_rem_next");
	printf("\n \t5. clist_destroy");
	printf("\n \t6. print");
	printf("\n \t7.exit");
	printf("\n================================================\n");
}


void main(void)
{
	void *da;
	CList *list;
	CListElmt *find_element;
	void *nu;
	int ch;
	if((list = (CList *)malloc(sizeof(CList))) == NULL)
	{
		printf("\n Unsuccesful ");
		return;
        }
	clist_init(list,free);
	for(;;)
	{
		menu_print();
                printf("\n enter choice number ==> ");
                scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("\n input data ===> ");
				scanf("%s",&da);
				clist_ins_next(list,NULL,&da);
				break;
			case 2:
				printf("\n input  number of finding data==>");
				scanf("%s",&nu);
				find_element = find(list,&nu);
				if(find_element == NULL)
				{
					printf("\n None exist finding data");
					break;
                                }
				printf("\n finding Succesful");
				printf("\n input next data ==>");
				scanf("%s",&da);
				clist_ins_next(list,find_element,&da);
				break;
			case 3:
				printf("\n delete only one from head");
				clist_rem_next(list,clist_head(list),(void **)&da);
				break;
			case 4:
				printf("\n input number of finding data==>");
				scanf("%s",&nu);
				find_element = find(list,&nu);
				if(find_element == NULL)
				{
					printf("\n None exist finding data ");
					break;
					
                                }
				printf("\n finding Succesful");
				printf("\n delete next to find data");
				clist_rem_next(list,find_element,(void **)&da);
				break;
			case 5:
				printf("\n ALL linked list free");
				clist_destroy(list);
                                break;
			case 6:
				print(list);
				break;
			case 7:
				exit(1);
			default :
				printf("\nTo again choice");
				break;
		}
	}
}


				 

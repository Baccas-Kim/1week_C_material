#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<mem.h>



#define MAX 60

typedef struct ListElmt_ {
	char data[MAX];
	struct ListElmt_ *next;
	}ListElmt;

typedef struct List_ {
	int size;
	int (*match)(const void *key1,const void *key2);
        void (*destroy)(void *data);
	ListElmt	*head;
	ListElmt 	*tail;
	}List;



int list_init(List *list,void (*destroy)(void *data));
void list_destroy(List *list);
int list_rem_next(List *list,ListElmt *element,void **data);
int list_ins_next(List *list,ListElmt *element,const void *data);
int list_rem_next(List *list,ListElmt *element,void **data);
void print(List *list);
void menu_print(void);
ListElmt *find_list(List *list,int nu);

#define list_size(list) ((list)->size)
#define list_head(list) ((list)->head)
#define list_tail(list) ((list)->tail)
#define list_is_head(list,element) ((element) == (list)->head ? 1 : 0)
#define list_is_tail(element) ((element)->next == NULL ? 1: 0)
#define list_data(element) ((element)->data)
#define list_next(element) ((element)->next)



int list_init(List *list,void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;
	return 1;
}


void list_destroy(List *list)
{
	void *data;
	while(list_size(list) > 0)
	{
		if(list_rem_next(list, NULL, (void **) &data) == 0 && list->destroy != NULL)

		{
			list->destroy(data);
		}
	}
	memset(list,0,sizeof(List));
	return;
}



        	

int list_ins_next(List *list, ListElmt *element , const void *data)
{
	ListElmt *new_element;
	if((new_element = (ListElmt *)malloc(sizeof(ListElmt))) == NULL)
		return -1;


        strcpy(new_element->data,(char *)data);
        if(element == NULL)
	{
		printf("\n\t HEAD");

		if(list_size(list) == 0)
                {
			list->tail = new_element;
                }
		new_element->next = list->head;
		list->head = new_element;
	}
	else{
		if(element->next == NULL)
                {
			list->tail = new_element;
                }

		new_element->next = element->next;
		element->next = new_element;
	}

	list->size++;
	return 0;
}



int list_rem_next(List *list,ListElmt *element,void **data)
{
	ListElmt *old_element;

	if(list_size(list) == 0)
		return -1;

	if(element == NULL)
	{
                printf("\n \t HEAD");
		*data = list->head->data;
                printf("\n %s",*data);
		old_element = list->head;
		list->head = list->head->next;
		if(list_size(list) == 0)
			list->tail = NULL;
	}

	else {
		if(element->next == NULL)
			return -1;

		*data = element->next->data;
		old_element = element->next;
		element->next = element->next->next;

		if(element ->next == NULL)
			list->tail = element;
	      }

		free(old_element);
		list->size--;


		return 0;
}


void print(List *list)
{

	ListElmt *t;
	t = list_head(list); 
	printf("\n print from HEAD to TAIL==>   ");
	while(t != NULL)
	{
		printf("\t%s",t->data);
        	t =list_next(t);
       	}
}

ListElmt *find_list(List *list,void *nu)
{
	ListElmt *find ;
        find = list_head(list);
	while(strcmp(list_data(find),(char *)nu) && find != NULL)
        {
		find = list_next(find);
	}
        printf("\n find %s data ",&list_data(find));
        return find;
	
} 
        	

void menu_print(void)
{
	printf("\n =============simple linked list menu =================");
	printf("\n 	1. list_insert_next");
        printf("\n 	2. find_list_insert_next");
	printf("\n 	3. list_rem_next   ");
        printf("\n 	4. find_list_delete_next");
	printf("\n	5. destroy");
	printf("\n 	6. print");
	printf("\n 	7.  exit\n");
}
        	

void main(void)
{
	void *next_da;
        void *ar;
        void *a;
        //char ar[MAX];
        //char a[MAX];
        int ch;
	int s;
	List *list;
        ListElmt *find_ele;
        if((list=(List *)malloc(sizeof(List))) == NULL)
	{
		printf("\n unsuccesful list");
		return ;
        }       
        if(!list_init(list,free))
	{
		printf("\n unsuccesful init_list");
        	return;
	}
	else
	while(1)
        {
		menu_print();
		printf("\n enter to list menu ==> " );
		scanf("%d",&ch);
                switch(ch)
		{
			case 1:
				printf("\ninput data to next head ==> ");
				scanf("%s",&ar);
				list_ins_next(list,NULL,&ar);
				break;
		       	case 2:
                        	printf("\ninput finding data == >");
				scanf("%s",&a);
				find_ele = find_list(list,&a);
				printf("\n succesful finding  ");
				printf("\n input next data ==>");
                                scanf("%s",&ar);
				list_ins_next(list,find_ele,&ar);
                                break;
			case 3:
				printf("\n clear to next head ");
				list_rem_next(list,NULL,(void **)&next_da);
				break;

			case 4: printf("\ninput finding data == >");
				scanf("%s",&a);
				find_ele = find_list(list,&a);
				printf("\n delete next to find data");
				list_rem_next(list,find_ele,(void **)&next_da);
                                break;
                        case 5:	printf("\n clear all linked list");
				list_destroy(list);
				break;
                        
			case 6:
				print(list);
				break;
			case 7:
				exit(1);
			default :
				printf("\n again choice ");
                		break;
		}
	}
}


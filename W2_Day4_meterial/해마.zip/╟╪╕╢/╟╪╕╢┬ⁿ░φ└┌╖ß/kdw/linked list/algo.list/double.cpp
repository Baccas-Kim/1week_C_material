#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define MAX 30

typedef struct DListElmt_ {
	char data[MAX];
	struct DListElmt_ *prev;
	struct DListElmt_ *next;

	}DListElmt;




typedef struct DList_ {
	int size;

	int (*match)(const void *key1, const void *key2);
	void (*destroy)(void *data);

	DListElmt *head;
	DListElmt *tail;

	} DList;


void dlist_init(DList *list, void (*destroy)(void *data));
void dlist_destroy(DList *list);
int dlist_ins_next(DList *list, DListElmt *element,const void *data);
int dlist_ins_prev(DList *list, DListElmt *element,const void *data);
int dlist_remove(DList *list,DListElmt *element,void **data);
void print(DList *list);
DListElmt *find(DList *list, void *key);

#define dlist_size(list)((list)->size)
#define dlist_head(list)((list)->head)
#define dlist_tail(list)((list)->tail)
#define dlist_is_head(element) ((element)->prev == NULL ? 1: 0)
#define dlist_is_tail(element) ((element)->next == NULL ? 1: 0)
#define dlist_data(element) ((element)->data)
#define dlist_next(element) ((element)->next)
#define dlist_prev(element) ((element)->prev)


void dlist_init(DList *list,void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;

	return;
}

int dlist_ins_next(DList *list, DListElmt *element, const void *data)
{
	DListElmt *new_element;

	if(element == NULL && dlist_size(list) != 0)
		return -1;

	if((new_element = (DListElmt *)malloc(sizeof(DListElmt))) == NULL)
		return -1;

	strcpy(new_element->data,(char *)data);

	if(dlist_size(list) == 0)
	{
		list->head = new_element;
		list->head->prev = NULL;
		list->head->next = NULL;
		list->tail = new_element;
	}

	else
	{
		new_element->next = element->next;
		new_element->prev = element;

		if(element->next == NULL)
			list->tail = new_element;
		else
			element->next->prev = new_element;


		element->next = new_element;

	}
	list->size++;
	return 0;
}

void print(DList *list)
{
	 DListElmt *element;
	 element = dlist_head(list);
	 printf("\n print ==> HEAD ");
	 while(element != NULL)
	 {
		printf("\t%s",element->data);
		 element = dlist_next(element);
	  }
}


int dlist_ins_prev(DList *list,DListElmt *element,const void *data)
{
	DListElmt *new_element;

	if(element == NULL && dlist_size(list) != 0)
		return -1;
	if((new_element = (DListElmt *)malloc(sizeof(DListElmt))) == NULL)
		return -1;

	strcpy(new_element->data,(char *)data);
	if(dlist_size(list) ==0)
	{
		list->head = new_element ;
		list->head->prev = NULL;
		list->head->next = NULL;
		list->tail = new_element;
	}
	else
	{
		new_element->next = element;
		new_element->prev = element->prev;

		if(element->prev == NULL)
			list->head = new_element;
		else
			element->prev->next = new_element;
		element->prev = new_element;
	}

	list->size++;

	return 0;
}



DListElmt *find(DList *list, void *key)
{
	DListElmt *pre_find;
        DListElmt *next_find;
	pre_find=dlist_tail(list);
        next_find=dlist_head(list);
	while(next_find != pre_find)
	{
		if((strcmp(dlist_data(pre_find),(char *)key)) == 0)
               	 	{
				printf("\n hit pre_find->data==> %s",dlist_data(pre_find));
				return pre_find;
                	}
		else if((strcmp(dlist_data(next_find),(char *)key))== 0)
                	{
				printf("\n hit next_find->data==> %s",dlist_data(next_find));
				return next_find;
			}

      		pre_find = dlist_prev(pre_find);
		next_find = dlist_next(next_find);
	}
	return ((strcmp(dlist_data(next_find),(char *)key)==0) ? next_find : NULL);
}


void dlist_destroy(DList *list)
{
	void *data;
	while(dlist_size(list) > 0)
	{
		if(dlist_remove(list,dlist_tail(list),(void **)&data) == 0 && list-> destroy != NULL)
		{
		list->destroy(data);
        	}
	}
	memset(list,0,sizeof(DList));
	return;
}

int dlist_remove(DList *list, DListElmt *element,void **data)
{
	if(element == NULL || dlist_size(list) == 0)
		return -1;

		*data = element->data;

		if(element == list->head)
		{
			list->head = element->next;
			if(list->head == NULL)
				list->tail = NULL;
			else
				element->next->prev = NULL;
		}
		else
		{
		element->prev->next = element->next;

		if(element->next == NULL)
			list->tail = element->prev;
		else
			element->next->prev = element->prev;
		}
		free(element);
                list->size--;
                return 0;
}


void menu_print(void)
{
	printf("\n =========double linked list menu==========");
	printf("\n \t1. insert data  by moving tail ");
	printf("\n \t2. insert data  by moving head ");
	printf("\n \t3. insert next finding data ");
	printf("\n \t4. insert prev finding data");
	printf("\n \t5. print from head ");
	printf("\n \t6. list destroy");
	printf("\n \t7. selete delete");
        printf("\n \t8. exit()");
	printf("\n");
}



void main(void)
{
	void *da;
        void *nu;
	DList *list;
        DListElmt *find_element;
	int ch;
        int pi;
        if((list = (DList *)malloc(sizeof(DList))) == NULL)
	{
		printf("\n Unsuccesful memory allocation");
		return;
        }
	dlist_init(list,free);
	for(;;)
	{
		menu_print();
		printf("\n enter to choice number==> ");
		scanf("%d",&ch);
		switch(ch)
		{
                	case 1: printf("\n input insart data ==>");
				scanf("%s",&da);
				dlist_ins_next(list,list->tail,&da);
                        	break;
			case 2:
				printf("\n input insert data ==>");
				scanf("%s",&da);
				dlist_ins_prev(list,list->head,&da);
				break;
			case 3:
				printf("\n enter finding data  ==>");
				scanf("%s",&nu);
				find_element = find(list,&nu);
				if(find_element==NULL)
				{
                                	printf("\n None exist finding data");
					return;
				}
                                printf("\n input insert data ==>");
				scanf("%s",&da);
				dlist_ins_next(list,find_element,&da);
				break;
		        case 4:
				printf("\n enter finding data  ==>");
				scanf("%s",&nu);
				find_element = find(list,&nu);
				if(find_element==NULL)
				{
                                	printf("\n None exist finding data");
					return;
				}
				printf("\n input insert data ==>");
				scanf("%s",&da);
				dlist_ins_prev(list,find_element,&da);
				break;
                        case 5:
				print(list);
				break;
			case 6:
				printf("\nfree ALL linked list");
				dlist_destroy(list);
				break;
			case 7:
				printf("\n enter finding data  ==>");
				scanf("%s",&nu);
				find_element = find(list,&nu);
				if(find_element==NULL)
				{
                                	printf("\n None exist finding data");
					return;
				}
                                printf("\n delete finding data ");
				dlist_remove(list,find_element,(void **)&da);
				break;
			case 8:
                        	exit(1);
			default:
				printf("\n input choice again");
				break;
		 }
        }
}









         


#include<stdio.h>
#include<conio.h>

#define MAX 30

struct mark{
	     float total;
	     float average;
	     char grade;
	     };
struct student{
		char name[20];
		int *number[10];
		int score;
		struct mark kl;
	}degree[MAX];
void aver(int y,int v);
void student_num(int x);
void print(int l);
void grad(int p);

void get_cource(int y);
void get_name(int k);
void main(void)
{
	int c,i;
	clrscr();
	printf("\ninput student count number==>");
	scanf("%d",&c);
	for(i=0;i<c;i++)
	{
		get_name(i);
		student_num(i);
		get_cource(i);
		aver(i,c);
		grad(i);
	}
	print(i);
}



void student_num(int o)
{
	printf("input student number==>");
	scanf("%d",&degree[o].number);
}
void print(int l)
{
	int k;
	for(k=0;k<l;k++)
	{
		printf("\n== NAME == NUMBER == TOTAL == AVERAGE == GRADE ==");
		printf("\n=  %s     %d        %f        %f         %c =",degree[k].name,degree[k].number,degree[k].kl.total,degree[k].kl.average,degree[k].kl.grade);
	}
}

void grad(int p)
{
	int c;
	if(degree[p].kl.average >= 90 && degree[p].kl.average <= 100)
	    degree[p].kl.grade = 'A';
	else if(degree[p].kl.average >=80)
	    degree[p].kl.grade = 'B';
	else if(degree[p].kl.average >=70)
	    degree[p].kl.grade = 'C';
	else if(degree[p].kl.average >=60)
	    degree[p].kl.grade = 'D';
	else
	    degree[p].kl.grade = 'F';
}

void aver(int y,int v)
{
	degree[y].kl.average = degree[y].kl.total / v ;
}

void get_cource(int y)
{
	int c,i;
	printf("input cource count number==>");
	scanf("%d",&c);
	for(i=0;i<c;i++)
	{
		printf("\ninput score ==>");
		scanf("%d",&degree[y].score);
		degree[y].kl.total += degree[y].score;
	}
}

void get_name(int k)
{
	printf("\ninput student name==>");
	scanf("%s",degree[k].name);
}



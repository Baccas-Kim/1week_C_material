#include<stdio.h>
#include<stdlib.h>

typedef struct _node
	{
		int key;
		struct _node *next;
	}node;
node *head, *tail;

void init_list()
{
	head = (node *)malloc(sizeof(node));
	tail = (node *)malloc(sizeof(node));
	head->next=tail;
	tail->next=tail;
}
int delete_next(node *t)
{
	node *s;
	if(t->next == tail)
		return 0;
	s = t->next;
	t->next = t->next->next;
	free(s);
	return 1;
}
node *find_node(int k)
{
	node *s;
	s = head->next;
	while(s->key != k && s != tail)
		s = s->next;
		return s;
}
node *ordered_insert(int k)
{
	node *s;
	node *p;
	node *r;
	p = head;
	s = p->next;
	while(s->key <= k && s != tail)
	{
		p=p->next;
		s=p->next;
	}
	r = (node *)malloc(sizeof(node));
	r->key = k;
	p->next = r;
	r->next = s;
	return r;
}
node *insert_node(int t,int k)
{
	node *s;
	node *p;
	node *r;
	p=head;
	s=p->next;
	while(s->key != k && s != tail)
	{
		p=p->next;
		s=p->next;
	}
	if(s != tail)
	{
	r = (node *)malloc(sizeof(node));
	r->key = k;
	p->next = r;
	r->next = s;
	}
	return r;
}
void print_list(node *v)
{
	printf("\n");
	while(v != tail)
	{
		printf("\t%d",v->key);
		v = v->next;
	}
}
void menu_print()
{
	printf("\n============welcome to my linked list==========");
	printf("\n1.ordered 2.delete_ne 3.insert_no 4.	print_li 5.exit");
        printf("\n===============================================");
}

void main(void)
{
	int f,data,ta;
	node *o;
	init_list();
	for(;;)
	{
		menu_print();
		printf("\ninput choice==>");
		scanf("%d",&f);
		switch(f)
		{
			case 1:
			{
			      printf("\ninput data==>");
			      scanf("%d",&f);
			      ordered_insert(f);
			}break;
			case 2:
			{
				printf("input delet data==>");
				scanf("%d",&f);
				o=find_node(f);
				if(delete_next(o))
					printf("\ndeleting %d is successful");
			}break;
			case 3:
			{
				printf("\ninput before data==>");
				scanf("%d",&data);
				printf("\ninput after data==>");
				scanf("%d",&ta);
				printf("\ninserting %d before %d",data,ta);
				insert_node(data,ta);
				printf("\ninserting %d before %d",data,ta);
			}break;
			case 4:
			{
				printf("printing");
				print_list(head->next);
			}break;
			case 5:
				exit(1);
			default:
				printf("again");
				break;
		}
	}
}


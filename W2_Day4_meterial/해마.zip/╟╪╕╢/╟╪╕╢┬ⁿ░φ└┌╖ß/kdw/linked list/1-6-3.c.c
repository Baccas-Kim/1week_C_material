#include<stdio.h>
#include<stdlib.h>

typedef struct _node
	{
		int key;
		struct _node *next;
	}node;
node *head, *tail;

void init_list()
{
	head = (node *)malloc(sizeof(node));
	tail = (node *)malloc(sizeof(node));
	head->next=tail;
	tail->next=tail;
}
node *ordered_insert(int k);
void print_list(node *t);
void main(void)
{
	int f;
	init_list();
	for(;;)
	{
		printf("input choice==>");
		scanf("%d",&f);
		switch(f)
		{
			case 1:
			{
			      printf("\ninput data==>");
			      scanf("%d",&f);
			      ordered_insert(f);
			}break;
			case 2:
			{
				printf("printing");
				printf("printing");
				print_list(head->next);
			}break;
			case 3:
				exit(1);
			default:
				printf("again");
				break;
		}
	}
}

void print_list(node *t)
{
	printf("\n");
	while( t != tail)
	{
		printf("%d",t->key);
		t=t->next;
	}
}
node *ordered_insert(int k)
{
	node *s;
	node *p;
	node *r;
	p=head;
	s=p->next;
	while(s->key <= k && s != tail)
	{
		p = p->next;
		s = p->next;
	}
	r = (node *)malloc(sizeof(node));
	r->key = r;
	p->next = r;
	r->next = s;
	return r;
}

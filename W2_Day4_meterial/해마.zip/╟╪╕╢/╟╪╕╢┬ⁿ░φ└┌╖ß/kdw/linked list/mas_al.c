#include<stdio.h>
#include<stdlib.h>
#include<string.h>


typedef struct ListElmt_ {
	void *data;
	struct ListElmt_ *next;
	}ListElmt;

typedef struct List_ {
	int size;
	int (*match)(const void *key1,const void *key2);
        void (*destroy)(void *data);
	ListElmt	*head;
	ListElmt 	*tail;
	}List;



int list_init(List *list,void (*destroy)(void *data));
void list_destroy(List *list);
int list_ins_next(List *list,ListElmt *element,const void *data);
int list_rem_next(List *list,ListElmt *element,void **data);
void print(List *list);
void menu_print(void);
ListElmt* find(int d);
#define list_size(list) ((list)->size)
#define list_head(list) ((list)->head)
#define list_tail(list) ((list)->tail)
#define list_is_head(list,element) ((element) == (list)->head ? 1 : 0)
#define list_is_tail(element) ((element)->next == NULL ? 1: 0)
#define list_data(element) ((element)->data)
#define list_next(element) ((element)->next)


int list_init(List *list,void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;
	return 1;
}


void list_destroy(List *list)
{
	void *data;
	while(list_size(list) > 0)
	{
		if(list_rem_next(list, NULL, (void **) &data) == 0 && list->destroy != NULL)

		{
			list->destroy(data);
		}
	}
	memset(list,0,sizeof(List));
	return;
}


int list_ins_next(List *list, ListElmt *element, const void *data)
{
	ListElmt *new_element;
	if((new_element = (ListElmt *)malloc(sizeof(ListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;

	if(element == NULL)
	{
		printf("\n head");

		if(list_size(list) == 0)
                {
			list->tail = new_element;
                }
		new_element->next = list->head;
		list->head = new_element;
	}
	else{
		if(element->next == NULL)
                {
			list->tail = new_element;
                }
		new_element->next = element->next;
		element->next = new_element;
}
	list->size++;
	return 0;
}



int list_rem_next(List *list,ListElmt *element,void **data)
{
	ListElmt *old_element;

	if(list_size(list) == 0)
		return -1;

	if(element == NULL)
	{
		*data = list->head->data;
		old_element = list->head;
		list->head = list->head->next;
		if(list_size(list) == 0)
			list->tail = NULL;
	}

	else {
		if(element->next == NULL)
			return -1;

		*data = element->next->data;
		old_element = element->next;
		element->next = element->next->next;

		if(element ->next == NULL)
			list->tail = element;
	      }

		free(old_element);
		list->size--;


		return 0;
}

void print(List *list)
{

	ListElmt *t;
	t = list_head(list);
	while(t != NULL)
	{
		printf("\nprint===> %d",list_data(t));
		t = list_next(t);
   	}
}
ListElmt * find(int nu)
{
	int i;
	List *ele;
	ListElmt *element;
	if((element = (ListElmt *)malloc(sizeof(ListElmt))) == NULL)
		return;
	if((ele = (List *)malloc(sizeof(List))) == NULL)
		return;
	element = list_head(ele);
	printf("\n element=  %d",element->data);
	for(i=1;i<=nu;i++)
	{
		element=list_next(element);
	}
	return   element;
}
void menu_print(void)
{
	printf("\n =============simple linked list menu =================");
	printf("\n 	1. list_insert_next");
	printf("\n 	2. find list_insert_next");
	printf("\n 	3. list_rem_next   ");
	printf("\n 	4. destroy");
	printf("\n 	5. print	");
	printf("\n 	6. exit		");
}


void main(void)
{
	void *da;
	void *next_da;
	int ch;
	int nu;
	List *list;
	ListElmt *find_element;
	if((list = (List *)malloc(sizeof(List))) == NULL)
		return;
	if(!list_init(list,free))
	{
		printf("\n unsuccesful init_list");
	}

	else
	while(1)
        {
		menu_print();
		printf("\n enter to list menu ==> " );
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("\ninput data to next head ==>");
				scanf("%d",&da);
				list_ins_next(list,NULL,da);
				break;
			case 2:
				printf("\n input find data number ");
				scanf("%d",&nu);
				find_element = find(nu);
				printf("\n finding to data ");
				printf("\n input next data ==> ");
				scanf("%d",da);
				list_ins_next(list,find_element,da);
				break;
			case 3:
				printf("\n clear to next head ");
				list_rem_next(list,NULL,(void **)&next_da);
				break;
			case 4:
				printf("\n clear all linked list");
				list_destroy(list);
				break;
			case 5:

				print(list);
				break;
			case 6:
				exit(1);
			default :
				printf("\n again choice ");
                		break;
		}
	}
}









                              



                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
			
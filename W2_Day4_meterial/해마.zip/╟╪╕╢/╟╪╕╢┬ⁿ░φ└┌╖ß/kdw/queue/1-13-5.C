#include<stdio.h>
#include<stdlib.h>


#define MAX 10
int Queue[MAX];
int front , rear;
void init_queue(void)
{
	front= rear =0;
	}
void clear_queue(void)
{
	front = rear;
}

int put(int k)
{
	if((rear+1)%MAX == front)
	{
		printf("\n Queue over flower");
		return -1;
	}
	Queue[rear]=k;
	rear = ++rear%MAX ;
	return k;
}

int get()
{
	int k;
	if(front == rear)
	{
		printf("\nQueue undef flower");
		return -1;
	}
	k=Queue[front];
	front=++front % MAX ;
	return k;
}

void print_all()
{
	int i;
	for(i=0;i<rear;i++)
	{
		printf("\n\t\t%d",Queue[i]);
	}
}


void menu_print()
{
	printf("\n======queue menu======");
	printf("\n\t\t1.put");
	printf("\n\t\t2.get");
	printf("\n\t\t3.print_all");
	printf("\n\t\t4.exit");
	printf("\n======================");
}

void main(void)
{
	int c;
	int data;
	while(1)
	{
		menu_print();
		printf("\ninput queue menu==>");
		scanf("%d",&c);
		switch(c)
		{
			case 1:
			{
				printf("\ninput put data==>");
				scanf("%d",&data);
				put(data);
			}break;
			case 2:
			{
				printf("\nget");
				data=get();
				printf("\n\t\tget data==>%d",data);
			}break;
			case 3:
			{
				print_all();
			}break;
			case 4:
				exit(1);
			default:
				printf("\nagain input queue menu");
			break;
		}
	}
}

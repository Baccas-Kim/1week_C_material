#include<stdio.h>
#include<alloc.h>


typedef struct _queue{
				   int key;
				   struct _queue *prev;
				   struct _queue *next;
				   }queue;

queue *head,*tail;

void initial_queue()
{
	head = (queue *)malloc(sizeof(queue));
	tail = (queue *)malloc(sizeof(queue));
	head->prev=head;
	head->next=tail;
	tail->prev=head;
	tail->next=tail;
}


void put(int k)
{
	queue *front;
	if((front = (queue *)malloc(sizeof(queue)))==NULL)
	{
		printf("\nout of memory");
		return ;
	}
	front->key = k;
	front->next = head->next;
	head->next->prev = front;
	head->next = front;
	front->prev = head;
}

void get()
{
	queue *rear;
	queue *p;
	rear = tail->prev;
	if(rear==head)
	{
		printf("\nunder flower");
		return;
	}
	printf("\n\t\tget data== %d",rear->key);
	p=rear;
	rear->prev->next=tail;
	tail->prev=rear->prev;
	free(p);
}

void clear_queue()
{
	queue *p;
	queue *o;
	p=tail->prev;
	while(p!=head)
	{
		o=p;
		p=p->prev;
		free(o);
	}
	head->next=tail;
	tail->prev=head;
}
void print_all()
{
	queue *p;
	p=tail->prev;
	while(p!=head)
	{
		printf("\ndata in queue ==> %d",p->key);
		p=p->prev;
	}
}
void menu_print()
{
	printf("\n======queue use of double linked list======");
	printf("\n\t\t1.put");
	printf("\n\t\t2.get");
	printf("\n\t\t3.clear_queue");
	printf("\n\t\t4.print_all");
	printf("\n\t\t5.exit");
	printf("\n===========================================");
}
void main(void)
{
	int c;
	int data;
	initial_queue();
	while(1)
	{
		menu_print();
		printf("\ninput queue menu==>");
		scanf("%d",&c);
		switch(c)
		{
			case 1:
			{
				printf("\ninput queue data==>");
				scanf("%d",&data);
				put(data);
			}break;
			case 2:
			{
				printf("\nget");
				get();
			}break;
			case 3:
			{
				printf("\n\t\tclear queue");
				clear_queue();
			}
			break;
			case 4:
			{
				printf("\nprinting for data in queue");
				print_all();
			}break;

			case 5:
				exit(1);
			default:
				printf("\nagain input queue menu");
		}
	}
}



#include<stdio.h>

#if 0
int fibonacci(int n)
{
	if(n==1 || n==2)
		return 1;
	else
	    return fibonacci<n-1> + fibonacci(n-2);
}

#endif

int iter_fibonacci(int n)
{
	int r=0;
	int a=1,b=1;
	if(n==1 || n==2)
	return 1;
	while(n-- > 2)
	{
		r = a+b;
		a =b;
		b = r;
		printf("\na==> %d b==> %d r==> %d n==>%d",a,b,r,n);
	}
	return r;
}

void main(void)
{
	int a;
	a = iter_fibonacci(5);
	printf("\n===>%d",a);

}

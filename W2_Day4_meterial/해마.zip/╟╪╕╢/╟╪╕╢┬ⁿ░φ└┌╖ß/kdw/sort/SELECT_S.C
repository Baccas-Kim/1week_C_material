#include<stdio.h>
#include<alloc.h>
#include<mem.h>

#define MAX 30
int init_cmp(const void *k,const void *j)
{
      return(*(int *)k - *(int *)j);
}

void select_sort(void *base, size_t nelem , size_t width , int (*fcmp)(const void *,const void *))
{
	void *min;
	int minindex;
	int i,j;
	min = malloc(width);
	for(i=0;i<nelem - 1;i++)
	{
		minindex = i;
		memcpy(min,(char *)base +i*width,width);
		for(j=i+1;j<nelem;j++)
		{
			if(fcmp(min,(char*)base + j * width) > 0)
			{
				memcpy(min,(char *)base + j*width , width);
				minindex = j;
			}
		}
		memcpy((char *)base + minindex * width, (char *)base + i*width,width);
		memcpy((char *)base + i*width,min,width);
	}
	free(min);
}

void get_array(int *t,int b)
{
	int i;
	for(i=0;i<b;i++)
	{
		printf("\ninput data==>");
		scanf("%d",&t[i]);
	}
}

void print_sort(int *t,int b)
{
	int i;
	for(i=0;i<b;i++)
	{
		printf("\nsortting ---->%d",*(t+i));
	}
}
void main(void)
{
	int a[MAX];
	int b;
	printf("\ninput count number==>");
	scanf("%d",&b);
	getchar();
	get_array(a,b);
	select_sort(a,b,sizeof(int),init_cmp);
	print_sort(a,b);
}


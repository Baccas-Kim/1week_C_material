#include<stdio.h>
#include<alloc.h>
#include<mem.h>


#define MAX 30
/*#define DEBUG_KIMSY */
/*#define DEBUG_KUMSY */

int icmp(const void *x,const void *y)
{
	#ifdef DEBUG_KUMSY
	printf("\n(char *)x==> %c",*(char *)x);
	printf("\t(char *)y==> %c",*(char *)y);
	#endif
	return *(char *)x-*(char *)y ;
}
void get_array(int *t,int i)
{
	int j;
	for(j=0;j!=i;j++)
	{
		printf("\ninput data ==>");
		scanf("%c",t+j);
		getchar();
	 }
}

void bubble_sort(void *base,size_t nelem, size_t width,int (*fcmp)(const void *x,const void *y))
{
	int i,j,s;
	void *t;
	if((t=malloc(width))==NULL)
	{
		printf("\nError : cann't to malloc");
	}
	else
	for(i=0;i<nelem-1;i++)
	{
		s=1;
		for(j=1;j<nelem-i;j++)
		{
			if(fcmp((char *)base + (j-1)*width,(char *)base + j*width) > 0)
			{


				#ifdef DEBUG_KIMSY
				printf("\n (int *)base + (j-1)*width===> %c",*((int*)base + (j-1)*width));
				#endif
				memcpy(t,(char *)base + (j-1)*width,width);
				memcpy((char *)base + (j-1)*width,(char *)base + j*width,width);
				memcpy((char *)base + j*width,t,width);
				s=0;
			}
		}
		#if 1
		if(s==1){
			printf("\n%d counft sorted",i);
			break;
			}
		#endif
	}
	free(t);
}

void print_array(char *t,int i)
{
	int j;
	for(j=0;j!=i;j++)
		printf("\n\tsortting ===> %c",*(t+j));
}

void main(void)
{
	int a[MAX];
	int n;
	printf("\ninput array size==>");
	scanf("%d",&n);
	getchar();
	get_array(a,n);
	bubble_sort(a,n,sizeof(int),icmp);
	print_array(a,n);
}

#include<stdio.h>
#include<alloc.h>


#define MAX 100
int stack[MAX];
int top;
int is_stack_empty();
void quick_sort1(char a[],int d);
int queue(int da);
int pop();
void print(char a[], int d);
void get_array(char *a,int d);
/*int icmp(int x,int y);  */
/*int (*temp)(int x,int y);   */
void init_stack()
{
	top=-1;
}




void main(void)
{
	char *ar;
	int d;
	printf("\ninput size of array ==>");
	scanf("%d",&d);
	getchar();
	if((ar=(char *)malloc(sizeof(char)*d))==NULL)
	{
		printf("\n None sucessful ");
		exit(1);
	}
	get_array(ar,d);
	quick_sort1(ar,d);
}

void print(char a[],int d)
{
	int i;
	for(i=0;i<d;i++)
		printf("\nprint sorted data==> %c ",a[i]);
}

void get_array(char *a,int d)
{
	int i;
	for(i=0;i<d;i++)
	{
		printf("\n input data ==>");
		scanf("%c",a+i);
		getchar();
	}
}


int is_stack_empty()
{
	return top < 0;
}

int push(int da)
{
	if(top >MAX)
	{
		printf("\n Over flower");
		return -1;
	}
	stack[++top]=da;
	return da;
}


int pop()
{
	if(top<0)
	{
		printf("\n Under flower");
		return -1;
	}
	return stack[top--];
}




int icmp(int x,int y)
{
	return x - y;
}

void quick_sort1(char a[],int d)
{
	int v,t;
	int i,j;
	int l,r;
	init_stack();
	l =0 ;
	r = d-1;
	push(r);
	push(l);
	while(!is_stack_empty())
	{
		l = pop();
		r = pop();
		printf("\nprint l==> %d",l);
		printf("\t\tprint r==> %d",r);
		if(r-l+1>1)
		{
			v = a[r];
			i = l-1;
			j = r;
			while(1)
			{
				while(a[++i]<v);
				while(a[--j]>v);
				if(i >=j)break;
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
			printf("\npivot ==> %c", a[r]);
			printf("\na[i] ==> %c",a[i]);
			t = a[i];
			a[i] = a[r];
			a[r] = t;
			#if 0
			push(r);
			push(i+1);
			push(i-1);
			push(l);
			#endif
			#if 1
			printf("\n push r==>%d",push(r));
			printf("\tpush(i+1)==>%d", push(i+1));
			printf("\tpush(i-1)==>%d",push(i-1));
			printf("\tpusk(l) ==>%d",push(l));
			#endif
		}
	}
}
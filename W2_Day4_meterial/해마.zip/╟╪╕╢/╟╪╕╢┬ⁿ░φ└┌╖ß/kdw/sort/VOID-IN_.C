#include<stdio.h>
#include<alloc.h>
#include<mem.h>

#define MAX 20

void insert_sort(void *base, size_t nelem, size_t width ,int(*fcmp)(const void*,const void *))
{
	int i,j;
	void *t;
	t = malloc(width);
	for(i=1;i<nelem;i++)
	{
		memcpy(t,(char *)base + i*width,width);
		j = i;
		while(fcmp((char*)base + (j-1)*width, t)>0 && j >0)
		{
			memcpy((char*)base + j*width,(char *)base + (j-1)*width,width);
			j--;
		}
		memcpy((char *)base + (j-1)*width,t,width);
	}
	free(t);
}

void get_array(int *t,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("\ninput data ==>");
		scanf("%d",t+i);
	}
}
int init_cmp(const void *k,const void *i)
{
	return (*(int *)k - *(int *)i);
}
void print_sort(int *t,int i)
{
	int j;
	for(j=0;j<i;j++)
		printf("sortting ==> %d",*(t+j));
}
void main(void)
{
	int a[MAX];
	int n;
	printf("\ninput count==>");
	scanf("%d",&n);
	get_array(a,n);
	print_sort(a,n);
	insert_sort(a,n,sizeof(int),init_cmp);
	print_sort(a,n);
}

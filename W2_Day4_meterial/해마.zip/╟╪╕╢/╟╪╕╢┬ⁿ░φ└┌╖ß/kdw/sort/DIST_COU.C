
#include<stdio.h>
#include<alloc.h>

#define MAX 20

int get_array(int *t)
{
	int k;
	int x;
	printf("\ninput size of array==>");
	scanf("%d",&k);
	for(x=0;x!=k;x++)
	{
		printf("\ninput data ==>");
		scanf("%d",t+x);
	}
	return k;
}
void dist_count(int *t,int n,int i)
{
	int *count,*b;
	int s;
	if((count = (int *)malloc(sizeof(int)*(i+1)))==NULL && (b = (int *)malloc(sizeof(int)*n)) == NULL)
	{
		printf("\n JJJJ");
	}
	else
	for(s=0;s<=i;s++)
		count[s]=0;
	for(s=0;s<n;s++)
	{
		count[t[s]]++;
	}
	for(s=2;s<=i;s++)
	{
		count[s] = count[s-1] + count[s];
	}
	for(s=n-1;s>=0;s--)
	{
		b[--coun+t[t[s]]] = t[s];
	}
	for(s=0;s<n;s++)
	{
		t[s] = b[s];
		printf("\n t[s] ==> %d",t[s]);
	}
	free(b);
	free(count);
}

#if 0
void print_array(int *t,int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("\ndist_count ==> %d",t[i]);
}

#endif

void main(void)
{
	int i;
	int k;
	int n;
	int ar[MAX];
	printf("\ninput array from 0 to ==>");
	scanf("%d",&i);
	n=get_array(ar);
	dist_count(ar,n,i);
	for(k=0;k<n;k++)
		printf("\n dist_count==> %d",ar[k]);

}









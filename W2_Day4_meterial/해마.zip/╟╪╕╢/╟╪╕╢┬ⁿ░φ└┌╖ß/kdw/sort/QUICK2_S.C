#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define MAX 30
int stack[MAX];
int top;
void print(int a[],int n);
void get_array(int a[],int n);
void quick_sort4(int a[],int n);
void insert_sort(int a[],int n);
void init_stack()
{
top = -1;
}
int is_stack_empty()
{
	return top<0;
}
int push(int da)
{
	if(top > MAX)
	{
		printf("\n Over flower ");
		return -1;
	}
	stack[++top]=da;
	return da;
}

int pop(void)
{
	if(top<0)
	{
		printf("\n Under flower ");
		return -1;
	}
	return stack[top--];
}

void main(void)
{
	int ar[MAX];
	int n;
	printf("\ninput size of array ==>");
	scanf("%d",&n);
	#if 0
	if((ar=(malloc(sizeof(char)*n))) == NULL)
	{
		printf("\nNone successful");
		exit(1);
	}
	#endif
	get_array(ar,n);
	/*print(ar,n);  */
	quick_sort4(ar,n);
	/*print(ar,n);*/
}

void insert_sort(int a[],int n)
{
	int i,j,t;
	printf("\n n==> %d",n);
	for(i=1;i<n;i++)
	{
		t=a[i];
		j=i;
		while(a[j-1]>t && j>0)
			{
				a[j]=a[j-1];
				printf("\n a[j]==>%d",a[j]);
				j--;
			}
	a[j]=t;
	}
}

void quick_sort4(int a[],int n)
{
	int v,t;
	int i,j;
	int l,r;
	init_stack();
	l=0;
	r = n-1;
	push(r);
	push(l);
	#if 0
	printf("\n push(r)==> %d",push(r));
	printf("\n push(l)==> %d",push(l));
	#endif
	while(!is_stack_empty())
	{
		l = pop();
		r = pop();
		#if 0
		printf("\n l==> %d",l);
		printf("\n r==> %d",r);
		#endif
		if(r-l+1 > 200)
		{
			t= (r+l) >> 1;
			if(a[l] > a[t])
			{
				v = a[l];
				a[l] = a[t];
				a[t] = v;

			}
			if(a[l] > a[r])
			{
				v = a[l];
				a[l] = a[r];
				a[r] = v;
			}
			if(a[t] > a[r])
			{
				v = a[t];
				a[t] = a[r];
				a[r] = v;
			}
			v = a[t];
			a[t] = a[r-1];
			a[r-1] = v;
			i=l;
			j=r-1;
			while(1)
			{
				while(a[++i]<v);
				while(a[--j]>v);
				if(i >= j)break;
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		t=a[i];
		a[i] = a[r-1];
		a[r-1] = t;
		push(r);
		push(i+1);
		push(i-1);
		push(l);
		}
		else
		insert_sort(a+l,r-l+1);
	}
}




void print(int a[],int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("\nprint sorted for data===> %d",a[i]);
}



void get_array(int a[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("\ninput data ==>");
		scanf("%d",&a[i]);
	}
}




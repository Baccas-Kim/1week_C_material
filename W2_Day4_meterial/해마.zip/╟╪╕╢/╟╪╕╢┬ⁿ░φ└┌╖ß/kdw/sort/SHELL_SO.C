#include<stdio.h>

#define MAX 20


void get_array(int *t,int i)
{
	int k;
	for(k=0;k<i;k++)
	{
		printf("\ninput data ==>");
		scanf("%d",t+k);
	}
}

void shell_sort(int *t,int i)
{
	int s,h,j;
	int x,k;
	for(h=i/2;h>0;h/=2)
	{
		for(x=0;x<h;x++)
		{
			for(j = x+h;j<i;j+=h)
			{
				s=t[j];
				k=j;
				while(k>h-1 && t[k-h] > s)
				{
				    t[k] = t[k-h];
				    k-=h;
				}
			t[k] = s;
			}
		}
	}
}

void print_sort(int *t,int i)
{
	int k;
	for(k=0;k!=i;k++)
		printf("\nsortting===> %d",*(t+k));
}

void main(void)
{
	int a[MAX];
	int n;
	printf("input count number==>");
	scanf("%d",&n);
	get_array(a,n);
	shell_sort(a,n);
	print_sort(a,n);
}

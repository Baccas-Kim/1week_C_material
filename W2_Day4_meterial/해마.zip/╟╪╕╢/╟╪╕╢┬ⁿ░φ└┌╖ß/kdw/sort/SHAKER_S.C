#include<stdio.h>
#include<alloc.h>

#define MAX 30
#define swap(x,y,temp)((temp)=(x),(x)=(y),(y)=(temp))


void get_array(int *t,int i)
{
	int j;
	for(j=0;j!=i;j++)
	{
		printf("input data ==>");
		scanf("%d",t+j);
	}
}

void shaker_sort(int *t,int n)
{
	int i,j=n-1,tem,s;
	while(1)
	{
		s=1;
		for(i=1;i!=n;i++)
		{
			if(t[i-1]>t[i]){
			swap(t[i-1],t[i],tem);
			s=0;
			}
		}
		if(s==0)
		for(;j>0;j--)
		{
			if(t[j-1]>t[j]){
			swap(t[j-1],t[j],tem);
			s=0;
			}
		}
		else{
			printf("i=%d &&j=%d count sorted",i,j);
			break;
			}
	}
}


void print_array(int *t,int i)
{
	int j;
	for(j=0;j!=i;j++)
		printf("\nsortting ===> %d",*(t+j));
}
void main(void)
{
	int a[MAX];
	int n;
	printf("\ninput array size==>");
	scanf("%d",&n);
	get_array(a,n);
	shaker_sort(a,n);
	print_array(a,n);
}

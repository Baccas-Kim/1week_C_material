#include<stdio.h>

#define MAX 20

void redix_exchange_sort(int a[],int n,int b,unsigned (*ff)(unsigned x,int k,int j));
unsigned bits(unsigned x, int k, int j);
void print(int a[],int s);
void main(void)
{
	int ar[MAX];
	int s;
	int i;
	printf("\n input size of array ==>");
	scanf("%d",&s);
	for(i=0;i<s;i++)
	{
		printf("\n input data ==>");
		scanf("%d",&ar[i]);
	}
	redix_exchange_sort(ar,s,15,bits);
	/*print(ar,s); */
}
void print(int a[],int s)
{
	int i;
	for(i=0;i<s;i++)
		printf("\n print sorted data ====> %d",a[i]);
	}


unsigned bits(unsigned x, int k, int j)
{
	return (x>>k)&~(~0<<j);
}
void redix_exchange_sort(int a[], int n,int b,unsigned (*ff)(unsigned x,int k,int j))
{
	int t,i,j,x=0;
	if(n>1 && b>=0)
	{
		i=0;
		j=n-1;
		while(1)
		{
			while(ff(a[i],b,1) == 0 && i<j) i++;
			while(ff(a[j],b,1) != 0 && i<j) j--;
			if(i>=j) break;
			t = a[i];
			a[i] = a[j];
			a[j] = t;
		}
		if(ff(a[n-1],b,1) == 0) j++;
		#if 1
				printf("\nredix 111111");
		printf("\t j==> %d, b-1==> %d",j,b-1);
		#endif
		redix_exchange_sort(a,j,b-1,bits);
		#if 1
		printf("\n");
		printf("\t n==> %d ,j ==> %d, b== >%d",n,j,b);
		printf("\t n-j==> %d ,b-1 ==> %d",n-j,b-1);
		#endif
		redix_exchange_sort(a+j,n-j,b-1,bits);
		}
}

#include<stdio.h>
#include<alloc.h>


#define W 16
#define M 4
#define MV (1<<M)
#define MAX 30
void print(int a[],int s);
unsigned bits(unsigned x,int k,int j);
void straight_radix_sort(int a[], int n,unsigned (*ff)(unsigned x,int k,int j));

void main(void)
{
	int ar[MAX];
	int s;
	int i;
	printf("\ninput size of array ==>");
	scanf("%d",&s);
	for(i=0;i<s;i++)
	{
		printf("\n input data ==>");
		scanf("%d",&ar[i]);
	}
	straight_radix_sort(ar,s,bits);
	/*print(ar,s); */
}
void print(int a[],int s)
{
	int i;
	for(i=0;i<s;i++)
		printf("\n sorted data ==> %d",a[i]);
}



unsigned bits(unsigned x,int k, int j)
{
	return (x>>k) &~(~0<<j);
}

void straight_radix_sort(int a[],int n,unsigned (*ff)(unsigned x,int k,int j))
{
	int i,j;
	int *b, *count;
	b = (int *)malloc(sizeof(int)*n);
	count = (int *)malloc(sizeof(int)*MV);
	for(i=0;i<W/M;i++)
	{
		for(j = 0;j<MV;j++)
			count[j] = 0;
		for(j =0 ;j<n;j++)
			count[ff(a[j],i*M,M)]++;
		for(j = 1;j<MV;j++)
			count[j]=count[j]+count[j-1];
		for(j = n-1;j>=0;j--)
			b[--count[ff(a[j],i*M,M)]]=a[j];
		for(j =0 ;j<n;j++)
			a[j] = b[j];
	}
	free(b);
	free(count);
}

#include<stdio.h>

#define MAX 30


void get_array(int *t,int n)
{
	int i;
	for(i=1,*(t+0)=-1;i<n;i++)
	{
		printf("\ninput data==>");
		scanf("%d",t+i);
	}
}

void insertion_sort(int *t,int n)
{
	int i,j,a;
	for(i=2;i<n;i++)
	{
		a=*(t+i);
		j=i;
		while(t[j-1]>a)
		{
			t[j]=t[j-1];
			j--;
		}
		t[j] = a;
	}
}

void print_sort(int *t,int n)
{
	int i;
	for(i=1;i != n;i++)
		printf("\nsortting===> %d",*(t+i));
}

void main(void)
{
	int a[MAX];
	int d;
	printf("\ninput data count ==>");
	scanf("%d",&d);
	get_array(a,d);
	insertion_sort(a,d);
	print_sort(a,d);
}


#include<stdio.h>

#define MAX 20

void indirect_insert_sort(int a[],int index[],int n)
{
	int i , j ;
	int t ;
	for(i=0;i < n; i++)
		index[i] = i;
	for(i=1;i<n;i++)
	{
		t = index[i];
		j=i;
		while(a[index[j-1]] > a[t] && j > 0)
		{
			index[j] = index[j-1];
			j--;
		}
		index[j] = t;
	}
}

void get_array(int t[],int k)
{
	int i;
	for(i=0;i != k;i++)
	{
		printf("\ninput data==>");
		scanf("%d",&t[i]);
	}
}

void print_array(int t[],int k)
{
	int i;
	for(i=0;i != k;i++)
		printf("\nsortting==>%d",t[i]);
}
void rearrange(int a[],int index[],int n)
{
	int *p;
	int i;
	p = (int *)malloc(sizeof(int)*n);
	for(i=0;i<n;i++)
		p[i] =a[index[i]];
	for(i=0;i<n;i++)
		a[i] = p[i];
	free(p);
}

void main(void)
{
	int a[MAX];
	int b[MAX];
	int c;
	printf("\ninput count ==>");
	scanf("%d",&c);
	get_array(a,c);
	indirect_insert_sort(a,b,c);
	printf("\nprint==> index \n");
	print_array(b,c);
	rearrange(a,b,c);
	printf("\nprint==> array");
	print_array(a,c);
}
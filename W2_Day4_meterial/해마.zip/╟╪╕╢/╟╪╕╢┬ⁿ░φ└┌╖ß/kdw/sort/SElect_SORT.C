#include<stdio.h>

#define MAX 20

void select_sort(int a[],int n);
void print_sort(int a[],int b);
void main(void)
{
	int a[MAX];
	int d,c;
	printf("\ninput array count ==>");
	scanf("%d",&d);
	for(c=0 ; c!=d ; c++)
	{
		scanf("%d",&a[c]);
	}
	select_sort(a,d);
	print_sort(a,d);
}

void select_sort(int a[],int n)
{
	int min;
	int minindex;
	int i,j;
	for(i=0;i<n-1;i++)
	{
		minindex=i;
		min=a[i];
		for(j=i+1;j<n;j++)
		{
			if( min > a[j])
			{
				printf("\nmin==>%d",min);
				printf("\na[j]==>%d",a[j]);
				min=a[j];
				minindex=j;
			}
			printf("\tfor==>min==>%d",min);
			printf("\tfor==>a[j]=>%d",a[j]);
		}
		printf("\n***mini==>%d a[i]==> %d",minindex,a[i]);
		a[minindex]=a[i];
		a[i]=min;
	}
}
#if 1
void print_sort(int a[],int b)
{

	int c;
	for(c=0;c<b;c++)
	{
		printf("\nsortting====> %d",a[c]);
	}
}
#endif
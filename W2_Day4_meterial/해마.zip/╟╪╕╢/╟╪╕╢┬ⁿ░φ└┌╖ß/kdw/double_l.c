#include<stdlib.h>
#include<stdio.h>
#include<string.h>


typedef struct DListElmt_ {
	void *data;
	struct DListElmt_ *prev;
	struct DListElmt_ *next;

	}DListElmt;




typedef struct DList_ {
	int size;

	int (*match)(const void *key1, const void *key2);
	void (*destroy)(void *data);

	DListElmt *head;
	DListElmt *tail;

	} DList;

void dlist_init(DList *list, void (*destroy)(void *data));
void dlist_destroy(DList *list);
int dlist_ins_next(DList *list, DListElmt *element,const void *data);
int dlist_ins_prev(DList *list, DListElmt *element,const void *data);
int dlist_remove(DList *list,DListElmt *element,void **data);
void print(DList *list);
//DListElmt *find(DListElmt *element,int nu);
DListElmt *find(DListElmt *element,int nu,int si);
#define dlist_size(list)((list)->size)
#define dlist_head(list)((list)->head)
#define dlist_tail(list)((list)->tail)
#define dlist_is_head(element) ((element)->prev == NULL ? 1: 0)
#define dlist_is_tail(element) ((element)->next == NULL ? 1: 0)
#define dlist_data(element) ((element)->data)
#define dlist_next(element) ((element)->next)
#define dlist_prev(element) ((element)->prev)


void dlist_init(DList *list,void (*destroy)(void *data))
{
	list->size = 0;
	list->destroy = destroy;
	list->head = NULL;
	list->tail = NULL;

	return;
}

int dlist_ins_next(DList *list, DListElmt *element, const void *data)
{
	DListElmt *new_element;

	if(element == NULL && dlist_size(list) != 0)
		return -1;

	if((new_element = (DListElmt *)malloc(sizeof(DListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;

	if(dlist_size(list) == 0)
	{
		list->head = new_element;
		list->head->prev = NULL;
		list->head->next = NULL;
		list->tail = new_element;
	}

	else
	{
		new_element->next = element->next;
		new_element->prev = element;

		if(element->next == NULL)
			list->tail = new_element;
		else
			element->next->prev = new_element;


		element->next = new_element;

	}
	list->size++;
	return 0;
}

void print(DList *list)
{
	 DListElmt *element;
	 element = dlist_head(list);
	 printf("\n print ==> HEAD ");
	 while(!dlist_is_tail(element))
	 {
	 	printf("\t%d",element->data);
		 element = dlist_next(element);
	  }
	 printf("\t %d",element->data);
}

int dlist_ins_prev(DList *list,DListElmt *element,const void *data)
{
	DListElmt *new_element;

	if(element == NULL && dlist_size(list) != 0)
		return -1;
	if((new_element = (DListElmt *)malloc(sizeof(DListElmt))) == NULL)
		return -1;

	new_element->data = (void *)data;
	if(dlist_size(list) ==0)
	{
		list->head = new_element ;
		list->head->prev = NULL;
		list->head->next = NULL;
		list->tail = new_element;
	}
	else
	{
		new_element->next = element;
		new_element->prev = element->prev;

		if(element->prev == NULL)
			list->head = new_element;
		else
			element->prev->next = new_element;
		element->prev = new_element;
	}

	list->size++;

	return 0;
}



DListElmt *find(DListElmt *element,int nu,int si)
{
	int i;
        if(dlist_is_head(element))
	{
                printf("\n finding from Head to Tail");
		for(i=1;i<=nu;i++)
			element=dlist_next(element);
	}
	else
	{
                printf("\n finding from Tail to Head");
		for(i=si;i != nu;i--)
		{
                	printf("\nFinding for data from tail ");
			element = dlist_prev(element);
		}
	}
	return element;
} 
			 

void dlist_destroy(DList *list)
{
	void *data;
	while(dlist_size(list) > 0)
	{
		if(dlist_remove(list,dlist_tail(list),(void **)&data) == 0 && list-> destroy != NULL)
		{
		list->destroy(data);
        	}
	}
	memset(list,0,sizeof(DList));
	return;
}

int dlist_remove(DList *list, DListElmt *element,void **data)
{
	if(element == NULL || dlist_size(list) == 0)
		return -1;

		*data = element->data;

		if(element == list->head)
		{
			list->head = element->next;
			if(list->head == NULL)
				list->tail = NULL;
			else
				element->next->prev = NULL;
		}
		else
		{
		element->prev->next = element->next;

		if(element->next == NULL)
			list->tail = element->prev;
		else
			element->next->prev = element->prev;
		}
		free(element);
}


void menu_print(void)
{
	printf("\n =========double linked list menu==========");
	printf("\n \t1. insert data  by moving tail ");
	printf("\n \t2. insert data  by moving head ");
	printf("\n \t3. insert next finding data ");
	printf("\n \t4. insert prev finding data");
	printf("\n \t5. print from head ");
	printf("\n \t6. list destroy");
	printf("\n \t7. selete delete");
        printf("\n \t8. exit()");
	printf("\n");
}
 


void main(void)
{
	void *da;
	DList *list;
        DListElmt *find_element;
	int ch;
        int nu;
	dlist_init(list,free);
	for(;;)
	{
		menu_print();
		printf("\n enter to choice number==> ");
		scanf("%d",&ch);
		switch(ch)
		{
                	case 1: printf("\n input insart data ==>");
				scanf("%d",&da);
				dlist_ins_next(list,list->tail,da);
                        	break;
			case 2:
				printf("\n input insert data ==>");
				scanf("%d",&da);
				dlist_ins_prev(list,list->head,da);
				break;
			case 3:
                                printf("\n enter finding data number ==>");
				scanf("%d",&nu);
				if(((dlist_size(list)>>1)-1) <= nu && nu <= dlist_size(list))
				{
					find_element = find(list->tail,nu,dlist_size(list));
					printf("\n input insert data ==>");
					scanf("%d",&da);
				        dlist_ins_next(list,find_element,da);
                                }
			       	else
				{
					find_element = find(list->head,nu,0);
					printf("\n input insert data ==>");
					scanf("%d",&da);
					dlist_ins_next(list,find_element,da);
				} 
				break;
                        case 4:
			        printf("\n enter finding data number ==>");
				scanf("%d",&nu);
				if(((dlist_size(list)>>1)-1) <= nu && nu <= dlist_size(list))
				{
					find_element = find(list->tail,nu,dlist_size(list));
					printf("\n input insert data ==>");
					scanf("%d",&da);
				        dlist_ins_prev(list,find_element,da);
                                }
			       	else
				{
					find_element = find(list->head,nu,0);
					printf("\n input insert data ==>");
					scanf("%d",&da);
					dlist_ins_prev(list,find_element,da);
				}
				break;
       			case 5:
				print(list);
				break;
			case 6:
				printf("\nfree ALL linked list");
				dlist_destroy(list);
				break;
			case 7:
				printf("\n enter finding data number ==>");
				scanf("%d",&nu);
				if(((dlist_size(list)>>1)-1) <= nu && nu <= dlist_size(list))
				{
					find_element = find(list->tail,nu,dlist_size(list));
					printf("\n delete finding data ");
                                	dlist_remove(list, find_element, (void **)&da);
                                }
			       	else
				{
					find_element = find(list->head,nu,0);
					printf("\n delete finding data ");
					dlist_remove(list,find_element,(void **)&da);
				}
				break;
			case 8:
                        	exit(1);
			default:
				printf("\n input choice again");
				break;
		 }
        }
}

        



        	



         


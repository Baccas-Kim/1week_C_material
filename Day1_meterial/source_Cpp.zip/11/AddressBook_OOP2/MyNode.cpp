#include "stdafx.h"
#include "MyNode.h"

CMyNode::CMyNode(void)
	: pNext(NULL)
{
}

CMyNode::~CMyNode(void)
{
}
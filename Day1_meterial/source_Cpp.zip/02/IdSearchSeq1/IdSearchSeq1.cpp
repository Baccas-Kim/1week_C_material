#include "stdafx.h"
#include <iostream>
using namespace std;

int nData(20);

int _tmain(int argc, _TCHAR* argv[])
{
	int nData(10);

	cout << nData << endl;
	cout << argc << endl;

	return 0;
}
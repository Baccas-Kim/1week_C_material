#include "stdafx.h"
#include <iostream>
using namespace std;

void TestFunc(int nParam) { }

int _tmain(int argc, _TCHAR* argv[])
{
	TestFunc(10);

	return 0;
}
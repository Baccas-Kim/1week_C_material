#include "stdafx.h"
#include "MyStringEx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	CMyStringEx strTest;
	strTest.SetString("�۸��̾Ƶ�");
	cout << strTest << endl;


	return 0;
}
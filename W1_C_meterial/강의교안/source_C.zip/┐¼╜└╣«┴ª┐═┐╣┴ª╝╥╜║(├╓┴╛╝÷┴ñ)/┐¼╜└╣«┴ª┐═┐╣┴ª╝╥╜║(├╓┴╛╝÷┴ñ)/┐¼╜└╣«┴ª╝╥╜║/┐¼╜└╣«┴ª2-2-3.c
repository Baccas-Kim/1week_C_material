#include <stdio.h>

int main(void)
{
	printf("%d %d %d %d", 1101, 13, 0xd, 015);

	return 0;
}
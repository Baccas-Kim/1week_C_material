#include <stdio.h>

int main(void)
{
	int a;

	a = a + 1;
	a = a + 2;
	a = a + 3;
	printf("a : %d", a);

	return 0;
}
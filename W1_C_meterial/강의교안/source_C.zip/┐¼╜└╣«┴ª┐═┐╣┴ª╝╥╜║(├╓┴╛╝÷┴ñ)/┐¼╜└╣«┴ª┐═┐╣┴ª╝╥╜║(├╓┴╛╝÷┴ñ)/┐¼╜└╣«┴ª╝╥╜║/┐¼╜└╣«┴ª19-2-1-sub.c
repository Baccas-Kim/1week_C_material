static int key;

void set_key(int val)
{
	key = val;
}

int get_key(void)
{
	return key;
}

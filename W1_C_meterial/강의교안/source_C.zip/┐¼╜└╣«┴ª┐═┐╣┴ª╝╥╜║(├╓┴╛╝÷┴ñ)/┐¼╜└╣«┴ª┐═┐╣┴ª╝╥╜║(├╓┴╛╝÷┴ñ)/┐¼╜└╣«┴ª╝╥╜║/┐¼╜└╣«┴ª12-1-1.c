#include <stdio.h>

int main(void)
{
	char *ps = "applepie";

	ps += 5;
	printf("%s", ps);

	return 0;
}
#include <stdio.h>

int main(void)
{
/*
	printf("Hello world!\n");
*/
	printf("Be\rHappy!\nBaby");

	return 0;
}
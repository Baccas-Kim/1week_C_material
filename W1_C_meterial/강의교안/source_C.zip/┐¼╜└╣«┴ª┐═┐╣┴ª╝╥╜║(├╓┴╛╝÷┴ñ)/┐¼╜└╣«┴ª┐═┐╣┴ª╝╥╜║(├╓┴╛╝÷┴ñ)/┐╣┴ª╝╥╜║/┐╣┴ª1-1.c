#include <stdio.h>

int main(void)
{
	printf("Be happy!");

	return 0;
}